var kolotibablo=(function(){"use strict";function M(t){return t}const a=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,T={matches:["*://*.kolotibablo.com/*"],cssInjectionMode:"ui",main(){let t=null,e;function o(){if(document.getElementById("cm-toast-style-binance"))return;const i=document.createElement("style");i.id="cm-toast-style-binance",i.textContent=`
                @keyframes cm-toast-slide-in {
                    from { opacity: 0; transform: translateX(120%) scale(0.9); }
                    to { opacity: 1; transform: translateX(0) scale(1); }
                }
                .cm-toast-binance {
                    position: fixed !important; 
                    top: 24px !important; 
                    right: 24px !important; 
                    bottom: auto !important; 
                    left: auto !important;
                    z-index: 2147483647 !important;
                    min-width: 320px; padding: 16px 20px; border-radius: 12px;
                    background: rgba(30, 35, 41, 0.95); backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.08); color: #eaecef;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.4); font-family: sans-serif;
                    display: flex; align-items: center; gap: 12px; overflow: hidden;
                    animation: cm-toast-slide-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                .cm-toast-icon { width: 22px; height: 22px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: 6px; background: rgba(255,255,255,0.05); }
                .cm-toast-content { flex: 1; }
                .cm-toast-title { font-weight: 600; font-size: 14px; color: #fff; margin-bottom: 2px; }
                .cm-toast-msg { font-size: 12px; color: #b7bdc6; }
                .cm-toast-progress-track { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: rgba(255,255,255,0.05); }
                .cm-toast-progress { height: 100%; width: 100%; transform-origin: left; transform: scaleX(1); }
                .cm-toast-binance.success .cm-toast-icon { color: #0ecb81; }
                .cm-toast-binance.success .cm-toast-progress { background: #0ecb81; }
                .cm-toast-binance.warn .cm-toast-icon { color: #f0b90b; }
                .cm-toast-binance.warn .cm-toast-progress { background: #f0b90b; }
                .cm-toast-binance.error .cm-toast-icon { color: #f6465d; }
                .cm-toast-binance.error .cm-toast-progress { background: #f6465d; }
                .cm-toast-binance.info .cm-toast-icon { color: #3b82f6; }
                .cm-toast-binance.info .cm-toast-progress { background: #3b82f6; }

                /* Premium Detection & Selection Effects */
                .cm-detecting {
                    position: relative;
                    outline: 2px solid #f0b90b !important;
                    outline-offset: -2px;
                    box-shadow: 0 0 20px rgba(240, 185, 11, 0.4) !important;
                    filter: brightness(1.1);
                    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                }
                .cm-selected {
                    outline: 2px solid #0ecb81 !important;
                    outline-offset: -2px;
                    box-shadow: 0 0 20px rgba(14, 203, 129, 0.4) !important;
                    filter: brightness(1.1);
                    transform: scale(0.98);
                    transition: all 0.2s ease;
                }
                @keyframes cm-pulse {
                    0% { opacity: 0.6; }
                    50% { opacity: 1; }
                    100% { opacity: 0.6; }
                }
            `,document.head.appendChild(i)}function s(i,n,d="success"){o(),t&&t.remove(),t=document.createElement("div"),t.className=`cm-toast-binance ${d}`,t.innerHTML=`
                <div class="cm-toast-icon">${d==="success"?"⚡":"⚠️"}</div>
                <div class="cm-toast-content">
                    <div class="cm-toast-title">${i}</div>
                    <div class="cm-toast-msg">${n}</div>
                </div>
                <div class="cm-toast-progress-track">
                    <div class="cm-toast-progress"></div>
                </div>
            `,document.body.appendChild(t);const u=t.querySelector(".cm-toast-progress");setTimeout(()=>{u.style.transition="transform 5000ms linear",u.style.transform="scaleX(0)"},10),clearTimeout(e),e=window.setTimeout(()=>{t?.remove(),t=null},5e3)}function r(){const i=document.querySelector('img.gr-image[src^="data:image"]');i&&(i.classList.add("cm-detecting"),setTimeout(()=>i.classList.remove("cm-detecting"),2e3))}let c="";function v(){const i=document.querySelector('img.gr-image[src^="data:image"]');if(!i||!i.src||i.src===c)return;if(c=i.src,!l){s("Service Inactive ⚠️",'Please enable "Kolotibablo Login" in extension settings to auto-solve.',"warn"),console.log("🚫 Captcha found but service is disabled");return}s("Captcha Detected 🔍","Starting auto-solving process...","info");const n=document.querySelector(".captcha-info strong")?.textContent?.trim()||"";a.runtime.sendMessage({type:"CAPTCHA_IMAGE",imageData:i.src,question:n,questionType:"objectClassify"}),r()}const w="config_services";let l=!1;const S=async()=>{try{const n=!!(await a.storage.local.get(w))?.[w]?.["Kolotibablo Login"]?.enable;!l&&n&&(c=""),l=n,v()}catch(i){console.error("Failed to get storage:",i)}};S(),a.storage.onChanged.addListener((i,n)=>{n==="local"&&i[w]&&S()});let x;const A=()=>{clearTimeout(x),x=window.setTimeout(()=>{l&&v()},50)};new MutationObserver(()=>{A()}).observe(document.body,{childList:!0,subtree:!0}),S(),setInterval(()=>{v()},1e3),a.runtime.onMessage.addListener(async i=>{if(i.type==="api_error"){s(i.error||"API error occurred","error");return}if(!l)return;const n=document.querySelectorAll(".captcha-widget .cell"),d=document.querySelector("button.btn.btn-primary"),m=i.solution;if(!Array.isArray(m)||m.length===0){setTimeout(()=>{d?.click()},500);return}m.forEach((y,L)=>{setTimeout(()=>{const E=n[y-1];E&&(E.click(),E.classList.add("cm-selected"))},L*150)});const u=m.length*150+500;setTimeout(()=>{},u),setTimeout(()=>{d?.click(),n.forEach(y=>y.classList.remove("cm-selected"))},u+3800)})}};function b(t,...e){}const I={debug:(...t)=>b(console.debug,...t),log:(...t)=>b(console.log,...t),warn:(...t)=>b(console.warn,...t),error:(...t)=>b(console.error,...t)};class p extends Event{constructor(e,o){super(p.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=o}static EVENT_NAME=h("wxt:locationchange")}function h(t){return`${a?.runtime?.id}:kolotibablo:${t}`}function C(t){let e,o;return{run(){e==null&&(o=new URL(location.href),e=t.setInterval(()=>{let s=new URL(location.href);s.href!==o.href&&(window.dispatchEvent(new p(s,o)),o=s)},1e3))}}}class g{constructor(e,o){this.contentScriptName=e,this.options=o,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=h("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=C(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return a.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,o){const s=setInterval(()=>{this.isValid&&e()},o);return this.onInvalidated(()=>clearInterval(s)),s}setTimeout(e,o){const s=setTimeout(()=>{this.isValid&&e()},o);return this.onInvalidated(()=>clearTimeout(s)),s}requestAnimationFrame(e){const o=requestAnimationFrame((...s)=>{this.isValid&&e(...s)});return this.onInvalidated(()=>cancelAnimationFrame(o)),o}requestIdleCallback(e,o){const s=requestIdleCallback((...r)=>{this.signal.aborted||e(...r)},o);return this.onInvalidated(()=>cancelIdleCallback(s)),s}addEventListener(e,o,s,r){o==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(o.startsWith("wxt:")?h(o):o,s,{...r,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),I.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:g.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){const o=e.data?.type===g.SCRIPT_STARTED_MESSAGE_TYPE,s=e.data?.contentScriptName===this.contentScriptName,r=!this.receivedMessageIds.has(e.data?.messageId);return o&&s&&r}listenForNewerScripts(e){let o=!0;const s=r=>{if(this.verifyScriptStartedEvent(r)){this.receivedMessageIds.add(r.data.messageId);const c=o;if(o=!1,c&&e?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",s),this.onInvalidated(()=>removeEventListener("message",s))}}function F(){}function f(t,...e){}const k={debug:(...t)=>f(console.debug,...t),log:(...t)=>f(console.log,...t),warn:(...t)=>f(console.warn,...t),error:(...t)=>f(console.error,...t)};return(async()=>{try{const{main:t,...e}=T,o=new g("kolotibablo",e);return await t(o)}catch(t){throw k.error('The content script "kolotibablo" crashed on startup!',t),t}})()})();
kolotibablo;