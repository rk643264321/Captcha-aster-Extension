import { RootState } from '../index'

export const selectAlerts = (state: RootState) => state.alert.alerts

export const selectLatestAlert = (state: RootState) => {
    const alerts = state.alert.alerts
    return alerts.length > 0 ? alerts[alerts.length - 1] : null
}

export const selectAlertById = (state: RootState, id: string) =>
    state.alert.alerts.find(alert => alert.id === id)
