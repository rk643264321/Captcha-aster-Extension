import { Middleware } from 'redux'
import toast from 'react-hot-toast'
import { ALERT_PUSH, ALERT_CLEAR, Alert } from './constants'

interface AlertAction {
    type: string
    payload: Alert | { id: string }
}

/**
 * Redux middleware to handle toast notifications
 * This middleware intercepts ALERT_PUSH actions and displays toasts using react-hot-toast
 */
export const alertMiddleware: Middleware = () => (next) => (action: any) => {
    // Pass the action to the next middleware/reducer first
    const result = next(action)

    // Handle alert actions
    if (action.type === ALERT_PUSH) {
        const alert = action.payload as Alert
        const { type, message, duration = 4000 } = alert

        // Display toast based on alert type
        switch (type) {
            case 'success':
                toast.success(message, { duration, id: alert.id })
                break

            case 'error':
                toast.error(message, { duration, id: alert.id })
                break

            case 'loading':
                toast.loading(message, { duration, id: alert.id })
                break

            case 'info':
                toast(message, {
                    duration,
                    id: alert.id,
                    icon: 'ℹ️'
                })
                break

            case 'warning':
                toast(message, {
                    duration,
                    id: alert.id,
                    icon: '⚠️',
                    style: {
                        background: '#f59e0b',
                        color: '#fff',
                    }
                })
                break

            default:
                toast(message, { duration, id: alert.id })
        }
    }

    if (action.type === ALERT_CLEAR) {
        const payload = action.payload as { id: string }
        toast.dismiss(payload.id)
    }

    return result
}
