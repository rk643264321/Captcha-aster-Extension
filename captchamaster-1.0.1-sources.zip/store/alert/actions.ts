import { ALERT_PUSH, ALERT_CLEAR, ALERT_CLEAR_ALL, AlertType } from './constants'

// Alert Actions
export const alertPush = (
    type: AlertType,
    message: string,
    duration?: number
) => ({
    type: ALERT_PUSH,
    payload: {
        id: `${Date.now()}-${Math.random()}`,
        type,
        message,
        duration,
        timestamp: Date.now()
    }
})

export const alertClear = (id: string) => ({
    type: ALERT_CLEAR,
    payload: { id }
})

export const alertClearAll = () => ({
    type: ALERT_CLEAR_ALL
})

// Convenience action creators
export const alertSuccess = (message: string, duration?: number) =>
    alertPush('success', message, duration)

export const alertError = (message: string, duration?: number) =>
    alertPush('error', message, duration)

export const alertInfo = (message: string, duration?: number) =>
    alertPush('info', message, duration)

export const alertWarning = (message: string, duration?: number) =>
    alertPush('warning', message, duration)

export const alertLoading = (message: string, duration?: number) =>
    alertPush('loading', message, duration)
