// Alert Action Types
export const ALERT_PUSH = 'ALERT_PUSH'
export const ALERT_CLEAR = 'ALERT_CLEAR'
export const ALERT_CLEAR_ALL = 'ALERT_CLEAR_ALL'

// Alert Types
export type AlertType = 'success' | 'error' | 'loading' | 'info' | 'warning'

export interface Alert {
    id: string
    type: AlertType
    message: string
    duration?: number
    timestamp: number
}
