import { ALERT_PUSH, ALERT_CLEAR, ALERT_CLEAR_ALL, Alert } from './constants'

export interface AlertState {
    alerts: Alert[]
}

const initialState: AlertState = {
    alerts: []
}

export const alertReducer = (
    state = initialState,
    action: any
): AlertState => {
    switch (action.type) {
        case ALERT_PUSH:
            return {
                ...state,
                alerts: [...state.alerts, action.payload]
            }

        case ALERT_CLEAR:
            return {
                ...state,
                alerts: state.alerts.filter(alert => alert.id !== action.payload.id)
            }

        case ALERT_CLEAR_ALL:
            return {
                ...state,
                alerts: []
            }

        default:
            return state
    }
}
