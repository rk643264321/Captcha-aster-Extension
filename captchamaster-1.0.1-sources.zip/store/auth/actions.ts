import {
  AUTH_REQUEST,
  AUTH_SUCCESS,
  AUTH_FAILURE,
  AUTH_LOGOUT,
  AUTH_CHECK,
  AUTH_LOGOUT_SUCCESS,
  AUTH_LOGOUT_FAILURE,
  PLAN_REQUEST,
  PLAN_SUCCESS,
  PLAN_FAILURE
} from './constants'

// Auth Actions
export const authRequest = (apiKey: string) => ({
  type: AUTH_REQUEST,
  payload: { apiKey }
})

export const authSuccess = (user: any, apiKey: string) => ({
  type: AUTH_SUCCESS,
  payload: { user, apiKey }
})

export const authFailure = (error: string) => ({
  type: AUTH_FAILURE,
  payload: { error }
})

export const authLogout = (navigate: any) => ({
  type: AUTH_LOGOUT,
  payload: { navigate }
})


export const authLogoutSuccess = () => ({
  type: AUTH_LOGOUT_SUCCESS
})

export const authLogoutFailure = () => ({
  type: AUTH_LOGOUT_FAILURE
})


export const authCheck = () => ({
  type: AUTH_CHECK
})

// Plan Actions
export const planRequest = () => ({
  type: PLAN_REQUEST
})

export const planSuccess = (plan: any) => ({
  type: PLAN_SUCCESS,
  payload: { plan }
})

export const planFailure = (error: string) => ({
  type: PLAN_FAILURE,
  payload: { error }
})