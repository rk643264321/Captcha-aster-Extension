import { takeLatest, put, call, delay } from 'redux-saga/effects'
import { AUTH_CHECK, AUTH_LOGOUT, AUTH_REQUEST, PLAN_REQUEST } from './constants'
import { authSuccess, authFailure, authLogout, authLogoutSuccess, authLogoutFailure, planSuccess, planFailure } from './actions';
import API_CALL from '@/lib/api';
import { alertSuccess, alertError, alertLoading, alertPush } from '../alert/actions';


// API validation function
function* validateApiKey(apiKey: string): Generator<any, boolean, any> {

  const { response, status } = yield call(API_CALL, { method: 'POST', url: '/auth/validate', body: { apiKey } })


  if (response && status === 200) {

    if (typeof window !== 'undefined') {
      localStorage.setItem('token', response.token);
      chrome.storage.local.set({ token: response.token });
    }
    return true
  } else {
    yield put(alertError(response.message?.error || 'Invalid API key'));
    yield put(authFailure(response.message?.error || 'Authentication failed'))
    return false
  }

}

function* authRequestSaga(action: any): Generator<any, void, any> {
  try {
    const { apiKey } = action.payload


    // Validate API key
    const isValid = yield call(validateApiKey, apiKey);



    if (isValid) {
      const token = localStorage.getItem('token')
      // Get user data from /me endpoint
      const userResponse = yield call(() => API_CALL({
        method: 'GET',
        url: '/auth/me',
        headers: {
          "X-CSRF-Token": token || undefined
        }
      }))

      if (userResponse.status === 200) {
        const user = userResponse.response

        yield delay(3000)
        yield put(authSuccess(user, apiKey))
        yield put(alertSuccess('Successfully authenticated!'))
      } else {
        throw new Error('Failed to fetch user data')
      }
    }
  } catch (error: any) {
    yield put(authFailure(error.message || 'Authentication failed'))
    // Show error alert
    yield put(alertError(error.message || 'Authentication failed'))
  }
}



function* authCheckSaga() {
  const token = localStorage.getItem('token');

  if (token) {
    const { status, response } = yield call(API_CALL, { url: '/auth/check', headers: { "X-CSRF-Token": token || undefined }, method: 'POST' })

    if (status === 200 && response) {
      yield delay(2000)
      yield put(authSuccess(response.user, response.apiKey))
      return;
    }
    yield put(alertPush('error', 'Authentication failed', 3000))
    yield put(authFailure('Authentication failed'))
  }

  yield put(authFailure('Authentication failed'))

}






function* authLogoutSaga(action: any) {
  const { response, status } = yield call(API_CALL, { url: '/auth/logout', headers: { "X-CSRF-Token": localStorage.getItem('token') || undefined }, method: 'POST' });
  if (response && status === 200) {
    localStorage.removeItem('token');
    chrome.storage.local.remove('token');
    yield put(alertSuccess('Successfully logged out!'))
    yield put(authLogoutSuccess());
    return;
  }
  yield put(alertPush('error', 'Logout failed', 3000))
  yield put(authLogoutFailure())
}

// Plan Request Saga
function* planRequestSaga(): Generator<any, void, any> {
  try {
    const token = localStorage.getItem('token')

    if (!token) {
      yield put(planFailure('No authentication token found'))
      return
    }

    const { response, status } = yield call(API_CALL, {
      method: 'GET',
      url: '/user/package',
      headers: {
        "X-CSRF-Token": token
      }
    })

    if (status === 200 && response) {
      yield put(planSuccess(response))
    } else {
      yield put(planFailure(response?.message || 'Failed to fetch plan data'))
    }
  } catch (error: any) {
    yield put(planFailure(error.message || 'Failed to fetch plan data'))
  }
}

export function* watchAuthRequest() {
  yield takeLatest(AUTH_REQUEST, authRequestSaga)
  yield takeLatest(AUTH_LOGOUT, authLogoutSaga)
  yield takeLatest(AUTH_CHECK, authCheckSaga)
  yield takeLatest(PLAN_REQUEST, planRequestSaga)
}

