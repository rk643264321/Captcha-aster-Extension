// Auth Action Types
export const AUTH_REQUEST = 'AUTH_REQUEST'
export const AUTH_SUCCESS = 'AUTH_SUCCESS'
export const AUTH_FAILURE = 'AUTH_FAILURE'
export const AUTH_LOGOUT = 'AUTH_LOGOUT'
export const AUTH_CHECK = 'AUTH_CHECK'
export const AUTH_LOGOUT_SUCCESS = 'AUTH_LOGOUT_SUCCESS'
export const AUTH_LOGOUT_FAILURE = 'AUTH_LOGOUT_FAILURE'

// Plan Action Types
export const PLAN_REQUEST = 'PLAN_REQUEST'
export const PLAN_SUCCESS = 'PLAN_SUCCESS'
export const PLAN_FAILURE = 'PLAN_FAILURE'

