import {
  AUTH_REQUEST,
  AUTH_SUCCESS,
  AUTH_FAILURE,
  AUTH_LOGOUT,
  AUTH_CHECK,
  AUTH_LOGOUT_FAILURE,
  AUTH_LOGOUT_SUCCESS,
  PLAN_REQUEST,
  PLAN_SUCCESS,
  PLAN_FAILURE
} from './constants'

interface AuthState {
  isAuthenticated: boolean
  user: any | null
  apiKey: string | null
  plan: any | null
  loading: boolean
  planLoading: boolean
  error: string | null
}

const initialState: AuthState = {
  isAuthenticated: false,
  user: null,
  apiKey: null,
  plan: null,
  loading: false,
  planLoading: false,
  error: null
}

export const authReducer = (state = initialState, action: any): AuthState => {
  switch (action.type) {
    case AUTH_REQUEST:
      return {
        ...state,
        loading: true,
        error: null
      }
    case AUTH_SUCCESS:
      return {
        ...state,
        isAuthenticated: true,
        user: action.payload.user,
        apiKey: action.payload.apiKey,
        loading: false,
        error: null
      }
    case AUTH_FAILURE:
      return {
        ...state,
        isAuthenticated: false,
        user: null,
        apiKey: null,
        loading: false,
        error: action.payload.error
      }
    case AUTH_LOGOUT:
      return {
        ...state,
        loading: true,
        error: null
      }
    case AUTH_LOGOUT_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload.error
      }
    case AUTH_LOGOUT_SUCCESS:
      return {
        ...state,
        isAuthenticated: false,
        user: null,
        apiKey: null,
        plan: null,
        loading: false,
        error: null
      }
    case AUTH_CHECK:
      return {
        ...state,
        loading: true,
        error: null
      }
    case PLAN_REQUEST:
      return {
        ...state,
        planLoading: true,
        error: null
      }
    case PLAN_SUCCESS:
      return {
        ...state,
        plan: action.payload.plan,
        planLoading: false,
        error: null
      }
    case PLAN_FAILURE:
      return {
        ...state,
        planLoading: false,
        error: action.payload.error
      }
    default:

      return state
  }
}

export type { AuthState }

