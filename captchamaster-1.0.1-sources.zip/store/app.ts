import { authReducer } from "./auth"
import { alertReducer } from "./alert"
import { all } from 'redux-saga/effects'
import { createStore, applyMiddleware, compose, combineReducers } from 'redux'
import { watchAuthRequest } from './auth/sagas'

export const rootReducer = combineReducers({
  auth: authReducer,
  alert: alertReducer,
})

export function* rootSaga() {
  yield all([
    watchAuthRequest()
  ])
}
