import { createStore, applyMiddleware, compose, combineReducers } from 'redux'
import createSagaMiddleware from 'redux-saga'
import { rootReducer, rootSaga } from './app'
import { alertMiddleware } from './alert/middleware'

// Re-export auth items for convenience
export * from './auth'
// Re-export alert items for convenience
export * from './alert'

const sagaMiddleware = createSagaMiddleware()

const composeEnhancers =
  (typeof window !== 'undefined' && (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__) ||
  compose



export const store = createStore(
  rootReducer,
  composeEnhancers(applyMiddleware(sagaMiddleware, alertMiddleware))
)

sagaMiddleware.run(rootSaga)

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
