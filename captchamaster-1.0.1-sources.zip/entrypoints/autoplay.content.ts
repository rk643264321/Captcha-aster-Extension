export default defineContentScript({
    matches: ['*://*.kolotibablo.com/*'],
    main() {
        'use strict';
        const CONFIG_KEY = 'config_services';

        // ===== TOAST SYSTEM (BINANCE STYLE) =====
        let toastEl: HTMLDivElement | null = null;
        let toastHideTimer: number | undefined;

        function injectToastStyle() {
            if (document.getElementById('cm-autoplay-toast-style')) return;
            const style = document.createElement('style');
            style.id = 'cm-autoplay-toast-style';
            style.textContent = `
                @keyframes cm-toast-slide-in {
                    from { opacity: 0; transform: translateX(120%) scale(0.9); }
                    to { opacity: 1; transform: translateX(0) scale(1); }
                }
                .cm-toast-binance {
                    position: fixed !important; 
                    top: 80px !important; 
                    right: 24px !important; 
                    bottom: auto !important; 
                    left: auto !important;
                    z-index: 2147483647 !important;
                    min-width: 300px; padding: 16px 20px; border-radius: 12px;
                    background: rgba(30, 35, 41, 0.95); backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.08); color: #eaecef;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.4); font-family: sans-serif;
                    display: flex; align-items: center; gap: 12px; overflow: hidden;
                    animation: cm-toast-slide-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                .cm-toast-icon { width: 22px; height: 22px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: 6px; background: rgba(255,255,255,0.05); color: #f0b90b; }
                .cm-toast-content { flex: 1; }
                .cm-toast-title { font-weight: 600; font-size: 14px; color: #fff; margin-bottom: 2px; }
                .cm-toast-msg { font-size: 12px; color: #b7bdc6; }
                .cm-toast-progress-track { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: rgba(255,255,255,0.05); }
                .cm-toast-progress { height: 100%; width: 100%; transform-origin: left; transform: scaleX(1); background: #f0b90b; }
            `;
            document.head.appendChild(style);
        }

        function showToast(title: string, msg: string) {
            const timeoutMs = 3000;
            injectToastStyle();
            if (toastEl) toastEl.remove();

            toastEl = document.createElement('div');
            toastEl.className = 'cm-toast-binance';
            toastEl.innerHTML = `
                <div class="cm-toast-icon">▶️</div>
                <div class="cm-toast-content">
                    <div class="cm-toast-title">${title}</div>
                    <div class="cm-toast-msg">${msg}</div>
                </div>
                <div class="cm-toast-progress-track">
                    <div class="cm-toast-progress"></div>
                </div>
            `;
            document.body.appendChild(toastEl);

            const progressEl = toastEl.querySelector('.cm-toast-progress') as HTMLElement;
            setTimeout(() => {
                progressEl.style.transition = `transform ${timeoutMs}ms linear`;
                progressEl.style.transform = 'scaleX(0)';
            }, 10);

            clearTimeout(toastHideTimer);
            toastHideTimer = window.setTimeout(() => {
                toastEl?.remove();
                toastEl = null;
            }, timeoutMs);
        }

        const isServiceEnabled = (): Promise<boolean> => {
            return new Promise((resolve) => {
                browser.storage.local.get(CONFIG_KEY).then((result: any) => {
                    resolve(Boolean(result?.[CONFIG_KEY]?.['Auto Play']?.enable));
                });
            });
        };

        async function autoResume(): Promise<void> {
            const enabled = await isServiceEnabled();
            if (!enabled) return;

            // Look for div with class "play"
            const playBtn = document.querySelector<HTMLDivElement>('div.play');

            if (playBtn) {
                console.log('▶️ Play/Resume button detected → Clicking...');
                showToast('Auto Resuming', 'Play/Resume button clicked automatically');
               setTimeout(() => {
                 playBtn.click();
               }, 5000);
            }
        }

        // Perform an initial check
        autoResume();

        // Initialize MutationObserver to watch for DOM changes
        const observer = new MutationObserver(() => {
            autoResume();
        });

        // Start observing the body for child additions and subtree modifications
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class']
        });

        // Watch for storage changes (toggle switch)
        (chrome.storage as any).onChanged.addListener((changes: any) => {
            if (changes[CONFIG_KEY]) {
                autoResume();
            }
        });

        console.log('👀 MutationObserver active: Watching for play button...');
    },
});
