export default defineContentScript({
    matches: ['*://*.kolotibablo.com/*'],
    main() {
        'use strict';

        const CONFIG_KEY = 'config_services';

        // ===== TOAST SYSTEM (BINANCE STYLE) =====
        const TOAST_ID = 'cm-worker-toast';
        let toastEl: HTMLDivElement | null = null;
        let toastHideTimer: number | undefined;

        function injectToastStyle() {
            if (document.getElementById('cm-toast-style-binance')) return;
            const style = document.createElement('style');
            style.id = 'cm-toast-style-binance';
            style.textContent = `
                @keyframes cm-toast-slide-in {
                    from { opacity: 0; transform: translateX(120%) scale(0.9); }
                    to { opacity: 1; transform: translateX(0) scale(1); }
                }
                .cm-toast-binance {
                    position: fixed !important; 
                    top: 24px !important; 
                    right: 24px !important; 
                    bottom: auto !important; 
                    left: auto !important;
                    z-index: 2147483647 !important;
                    min-width: 320px; padding: 16px 20px; border-radius: 12px;
                    background: rgba(30, 35, 41, 0.95); backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.08); color: #eaecef;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.4); font-family: sans-serif;
                    display: flex; align-items: center; gap: 12px; overflow: hidden;
                    animation: cm-toast-slide-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                .cm-toast-icon { width: 22px; height: 22px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: 6px; background: rgba(255,255,255,0.05); }
                .cm-toast-content { flex: 1; }
                .cm-toast-title { font-weight: 600; font-size: 14px; color: #fff; margin-bottom: 2px; }
                .cm-toast-msg { font-size: 12px; color: #b7bdc6; }
                .cm-toast-progress-track { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: rgba(255,255,255,0.05); }
                .cm-toast-progress { height: 100%; width: 100%; transform-origin: left; transform: scaleX(1); }
                .cm-toast-binance.success .cm-toast-icon { color: #0ecb81; }
                .cm-toast-binance.success .cm-toast-progress { background: #0ecb81; }
                .cm-toast-binance.warn .cm-toast-icon { color: #f0b90b; }
                .cm-toast-binance.warn .cm-toast-progress { background: #f0b90b; }
            `;
            document.head.appendChild(style);
        }

        function showToast(title: string, msg: string, variant: 'success' | 'warn' = 'success') {
            const timeoutMs = 5000;
            injectToastStyle();
            if (toastEl) toastEl.remove();

            toastEl = document.createElement('div');
            toastEl.className = `cm-toast-binance ${variant}`;
            toastEl.innerHTML = `
                <div class="cm-toast-icon">${variant === 'success' ? '⚡' : '⚠️'}</div>
                <div class="cm-toast-content">
                    <div class="cm-toast-title">${title}</div>
                    <div class="cm-toast-msg">${msg}</div>
                </div>
                <div class="cm-toast-progress-track">
                    <div class="cm-toast-progress"></div>
                </div>
            `;
            document.body.appendChild(toastEl);

            const progressEl = toastEl.querySelector('.cm-toast-progress') as HTMLElement;
            setTimeout(() => {
                progressEl.style.transition = `transform ${timeoutMs}ms linear`;
                progressEl.style.transform = 'scaleX(0)';
            }, 10);

            clearTimeout(toastHideTimer);
            toastHideTimer = window.setTimeout(() => {
                toastEl?.remove();
                toastEl = null;
            }, timeoutMs);
        }

        const isServiceEnabled = (): Promise<boolean> => {
            return new Promise((resolve) => {
                chrome.storage.local.get(CONFIG_KEY, (result: any) => {
                    resolve(Boolean(result?.[CONFIG_KEY]?.['Auto Worker']?.enable));
                });
            });
        };

        const checkRedirect = async () => {
            const enabled = await isServiceEnabled();

            // Auto click "Start Working" button if found
            if (enabled) {
                const startBtn = document.querySelector('.btn.btn-primary.margin5px');
                if (startBtn instanceof HTMLElement) {
                    console.log('Auto Worker: Detected start button, clicking...');

                    setTimeout(() => {

                        startBtn.click();
                    }, 1000 * 10);
                }
            }


        };

        // Watch for storage changes (toggle switch)
        (chrome.storage as any).onChanged.addListener((changes: any) => {
            if (changes[CONFIG_KEY]) {
                checkRedirect();
            }
        });

        const observer = new MutationObserver(checkRedirect);
        observer.observe(document.body, { childList: true, subtree: true });

        // Initial check
        checkRedirect();
    },
});