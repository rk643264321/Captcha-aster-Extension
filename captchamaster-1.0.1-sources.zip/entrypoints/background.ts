import API_CALL, { API_BASE_URL } from "@/lib/api";

export default defineBackground(() => {
  // background.js (service worker)

  browser.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.type === 'CAPTCHA_IMAGE') {
      console.log('Received CAPTCHA_IMAGE message from content script.');

      try {
        // Check if extension is enabled and get token
        const storageData = await chrome.storage.local.get(['extensionEnabled', 'token']);
        const isEnabled = storageData.extensionEnabled !== false; // Default to true if not set
        const token = storageData.token;

        if (!isEnabled) {
          sendResponse({ success: false, message: 'Extension is disabled' });
          return;
        }
        if (!token) {
          if (sender.tab?.id) {
            browser.tabs.sendMessage(sender.tab.id, {
              type: 'api_error',
              error: 'not authorized'
            });
          }
          return;
        }

        // The base64 image data and question
        const { imageData, question, questionType } = message;


        const { response, status } = await API_CALL({ baseURL: API_BASE_URL, url: '/service', method: 'POST', body: JSON.stringify({ imageData, question, questionType }), headers: { "X-CSRF-Token": token || undefined } });

       
        if (response && response.success) {
          if (sender.tab?.id) {
            browser.tabs.sendMessage(sender.tab.id, {
              type: 'SOLVE_CAPTCHA',
              solution : response.solution
            });
          }
          sendResponse({ success: true, message: 'API response sent.' });
          return;
        }




        if (sender.tab?.id) {
          browser.tabs.sendMessage(sender.tab.id, {
            type: 'api_error',
            error: response?.error.message || 'API call failed.'
          });

        }



      } catch (error) {
        sendResponse({ success: false, message: 'API call failed.' });
      }
    }
  });

});
