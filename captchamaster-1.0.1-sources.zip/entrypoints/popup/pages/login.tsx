"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Key, Eye, EyeOff, ArrowRight, Chrome } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useNavigate } from "react-router-dom"
import toast from "react-hot-toast"
import Loading from "@/components/loading"
import { useAppDispatch, useAppSelector } from "@/store/hooks"
import { authRequest } from "@/store/auth"
import logo from "@/assets/icon.png"

interface LoginPageProps {
  onLogin: () => void;
}

export default function ExtensionLoginPage({ onLogin }: LoginPageProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [apiKey, setApiKey] = useState("")
  const [showApiKey, setShowApiKey] = useState(false)
  const navigate = useNavigate()

  // Redux hooks
  const dispatch = useAppDispatch()
  const { loading, error, isAuthenticated } = useAppSelector(state => state.auth)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])




  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate API key
    if (!apiKey.trim()) {
      toast.error("Please enter your API key")
      return
    }

    if (apiKey.length < 10) {
      toast.error("Invalid API key format")
      return
    }

    // Dispatch Redux action
    dispatch(authRequest(apiKey))
  }

  const handleGoogleLogin = () => {
    toast.success("Opening Google login...")
    setTimeout(() => {
      // Open Google OAuth in new window
      window.open('https://accounts.google.com/oauth/authorize?client_id=52868988626-s0rhvo8d0fj6gs9kr41fd4kpji2kkmhp.apps.googleusercontent.com&redirect_uri=http://lcalhost:3000&response_type=code&scope=email profile', '_blank')
    }, 3000);
  }

  if (loading) {
    return <Loading />
  }

  return (
    <div className="min-h-screen dark:bg-gray-900 bg-background flex items-center justify-center">
      <div className="w-[360px] dark:bg-gray-900 dark:border-gray-700 bg-background border border-border shadow-primary/5 overflow-hidden flex flex-col min-h-[600px]">
        {/* Header with Logo */}
        <div
          className={`px-6 pt-6 pb-4 text-center dark:border-gray-700 border-b border-border bg-gradient-to-b from-primary/5 to-transparent transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"}`}
        >
          {/* Animated Logo */}
          <div className="relative w-16 h-16 mx-auto mb-3">
            <div className="absolute inset-0 rounded-4xl bg-gradient-to-br from-primary/30 to-primary/10  " />
            <div className="absolute inset-1 rounded-xl bg-gradient-to-br  flex items-center justify-center overflow-hidden">
              <img
                src={logo}
                alt="CaptchaMaster Logo"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating particles */}
            <div
              className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-primary/60 animate-bounce"
              style={{ animationDelay: "0.1s" }}
            />
            <div
              className="absolute -bottom-1 -left-1 w-1.5 h-1.5 rounded-full bg-primary/40 animate-bounce"
              style={{ animationDelay: "0.3s" }}
            />
          </div>
          <h1 className="text-lg font-bold dark:text-slate-100 text-foreground">
            Captcha<span className="text-amber-500">Ɱaster</span>
          </h1>
          <p className="text-xs dark:text-slate-400 text-muted-foreground mt-1">Enter your API key to continue</p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleLogin} className="px-5 py-5 space-y-4 flex-1">
          {/* API Key Field */}
          <div
            className={`space-y-1.5 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "100ms" }}
          >
            <label className="text-xs font-medium dark:text-slate-100 text-foreground">API Key</label>
            <div className="relative">
              <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 dark:text-slate-400 text-muted-foreground" />
              <Input
                type={showApiKey ? "text" : "password"}
                placeholder="Enter your API key"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="pl-10 pr-10 h-10 dark:bg-gray-800/50 dark:border-gray-600 dark:text-slate-300 bg-secondary/30 border-border focus:border-primary text-sm"
              />
              <button
                type="button"
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 dark:text-slate-400 text-muted-foreground hover:dark:text-slate-300 hover:text-foreground transition-colors"
              >
                {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Forgot API Key */}
          <div
            className={`flex justify-end transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "250ms" }}
          >
            <button
              type="button"
              onClick={() => window.open('https://api.captchamaster.org', '_blank')}
              className="text-xs dark:text-orange-400 text-primary hover:underline"
            >
              Need API key?
            </button>
          </div>

          {/* Sign In Button */}
          <div
            className={`transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "300ms" }}
          >
            <Button
              type="submit"
              className="w-full h-10 bg-primary hover:bg-primary/90 text-primary-foreground font-medium text-sm group"
            >
              Sign In
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>

          {/* Divider */}
          <div
            className={`flex items-center gap-3 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "350ms" }}
          >
            <div className="flex-1 h-px dark:bg-gray-700 bg-border" />
            <span className="text-[10px] dark:text-slate-400 text-muted-foreground">OR</span>
            <div className="flex-1 h-px dark:bg-gray-700 bg-border" />
          </div>

          {/* Google Sign In */}
          <div
            className={`transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "400ms" }}
          >
            <Button
              type="button"
              variant="outline"
              onClick={handleGoogleLogin}
              className="w-full h-10 dark:bg-transparent dark:border-gray-600 bg-transparent border-border hover:dark:bg-gray-800/50 hover:bg-secondary/50 text-sm"
            >
              <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              Continue with Google
            </Button>
          </div>

          {/* Sign Up Link */}
          <div
            className={`text-center transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "450ms" }}
          >
            <p className="text-xs dark:text-slate-400 text-muted-foreground">
              Don&apos;t have an API key?{" "}
              <button
                type="button"
                onClick={() => window.open('https://captchamaster.org', '_blank')}
                className="text-xs dark:text-orange-400 text-primary font-medium hover:underline"
              >
                Get one here
              </button>
            </p>
          </div>
        </form>

        {/* Footer */}
        <div className="px-5 py-3 dark:border-gray-700 dark:bg-gray-800/30 border-t border-border bg-secondary/30 mt-auto">
          <div className="flex items-center justify-center gap-1.5 text-[10px] dark:text-slate-400 text-muted-foreground">
            <Chrome className="w-3 h-3" />
            <span>Chrome Extension v2.4.1</span>
          </div>
        </div>
      </div>
    </div>
  )
}
