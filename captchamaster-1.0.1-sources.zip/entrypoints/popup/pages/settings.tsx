'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft, Palette, Puzzle, Zap, Lock, Globe, ChevronRight, Sun, Moon, Monitor, Chrome } from 'lucide-react'
import { Switch } from '@/components/ui/switch'

const settingsSections = [
  {
    title: 'General',
    icon: Puzzle,
    settings: [
      { label: 'Auto-solve on page load', key: 'autoSolve', type: 'toggle', defaultValue: true },
      { label: 'Show solving notifications', key: 'notifications', type: 'toggle', defaultValue: true },
    ],
  },
  {
    title: 'Performance',
    icon: Zap,
    settings: [
      { label: 'Turbo mode', key: 'turbo', type: 'toggle', defaultValue: false },
      { label: 'Background solving', key: 'background', type: 'toggle', defaultValue: true },
    ],
  },
  {
    title: 'Privacy',
    icon: Lock,
    settings: [
      { label: 'Anonymous solving', key: 'anonymous', type: 'toggle', defaultValue: true },
      { label: 'Clear data on close', key: 'clearData', type: 'toggle', defaultValue: false },
    ],
  },
]

const themeOptions = [
  { label: 'Light', icon: Sun, value: 'light' },
  { label: 'Dark', icon: Moon, value: 'dark' },
  { label: 'System', icon: Monitor, value: 'system' },
]

interface SettingsPageProps {
  onNavigate: (page: string) => void
}

export function SettingsPage({ onNavigate }: SettingsPageProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [settings, setSettings] = useState<Record<string, boolean>>({
    autoSolve: true,
    notifications: true,
    turbo: false,
    background: true,
    anonymous: true,
    clearData: false,
  })
  const [theme, setTheme] = useState('dark')

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const toggleSetting = (key: string) => {
    setSettings((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <>
      <div className="dark:bg-gradient-to-b dark:from-gray-900 dark:to-gray-800 bg-gradient-to-b from-yellow-50/50 to-orange-50/30">
        <div className="w-[360px] dark:bg-gray-900 dark:border-gray-700 bg-white border border-yellow-100/40 rounded-2xl shadow-lg overflow-hidden">
          <header
            className={`px-4 py-3 dark:border-gray-700 dark:bg-gradient-to-b dark:from-gray-800 dark:to-gray-700 border-b border-yellow-100/30 bg-gradient-to-b from-yellow-50/60 to-orange-50/40 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'}`}
          >
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="w-8 h-8 dark:text-orange-400 dark:hover:text-orange-300 text-orange-700 hover:text-orange-900 flex items-center justify-center"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h1 className="text-sm font-semibold dark:text-slate-100 text-slate-900">Settings</h1>
        </div>
          </header>

          <div className="max-h-[420px] overflow-y-auto">
        <div className="px-4 py-3 dark:border-gray-700 border-b border-yellow-100/30">
          <div className="flex items-center gap-2 mb-3">
            <Palette className="w-4 h-4 dark:text-orange-400 text-orange-600" />
            <span className="text-xs font-medium dark:text-slate-100 text-slate-900">Appearance</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {themeOptions.map((option) => (
              <button
                key={option.value}
                onClick={() => setTheme(option.value)}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all ${
                  theme === option.value
                    ? 'dark:bg-orange-900/40 dark:border-orange-700/50 bg-orange-100/40 border-orange-300/50'
                    : 'dark:bg-gray-800/30 dark:border-gray-600/40 bg-orange-50/30 border-orange-100/30 hover:dark:border-gray-500/40 hover:border-orange-200/40'
                }`}
              >
                <option.icon
                  className={`w-5 h-5 ${theme === option.value ? 'dark:text-orange-400 text-orange-700' : 'dark:text-orange-600/60 text-orange-600/60'}`}
                />
                <span className="text-[10px] font-medium dark:text-slate-100">{option.label}</span>
              </button>
            ))}
          </div>
        </div>

        {settingsSections.map((section, sectionIndex) => (
          <div
            key={section.title}
            className="px-4 py-3 dark:border-gray-700 border-b border-yellow-100/30"
          >
            <div className="flex items-center gap-2 mb-3">
              <section.icon className="w-4 h-4 dark:text-orange-400 text-orange-600" />
              <span className="text-xs font-medium dark:text-slate-100 text-slate-900">{section.title}</span>
            </div>
            <div className="space-y-2">
              {section.settings.map((setting) => (
                <div
                  key={setting.key}
                  className="flex items-center justify-between py-2 px-3 rounded-lg dark:bg-gray-800/50 dark:hover:bg-gray-700/30 bg-orange-50/50 hover:bg-orange-100/30 transition-colors"
                >
                  <span className="text-xs dark:text-slate-300 text-slate-700">{setting.label}</span>
                  <Switch
                    checked={settings[setting.key]}
                    onCheckedChange={() => toggleSetting(setting.key)}
                    className="scale-75 data-[state=checked]:bg-orange-600"
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
          </div>

             {/* Footer */}
        <div className="px-5 py-3 dark:border-gray-700 border-t border-border dark:bg-gray-800/30 bg-secondary/30">
          <div className="flex items-center justify-center gap-1.5 text-[10px] text-muted-foreground">
            <Chrome className="w-3 h-3" />
            <span>Chrome Extension v2.4.1</span>
          </div>
        </div>
        </div>
      </div>
    </>
  )
}
