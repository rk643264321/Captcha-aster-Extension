'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft, Shield, Search } from 'lucide-react'
import { ExtensionCaptchaCard } from '@/components/extension-captcha-card'

const captchaServices = [
  {
    name: 'Google reCAPTCHA',
    description: 'v2, v3 & Invisible support',
    icon: <Shield className="w-5 h-5 text-blue-500" />,
    isPopular: true,
    isActive: true,
    color: '#4285F4',
  },
  {
    name: 'hCaptcha',
    description: 'Privacy-focused captcha',
    icon: <Shield className="w-5 h-5 text-cyan-600" />,
    isPopular: true,
    isActive: true,
    color: '#00838F',
  },
  {
    name: 'Cloudflare Turnstile',
    description: 'Smart verification',
    icon: <Shield className="w-5 h-5 text-orange-500" />,
    isPopular: true,
    isActive: false,
    color: '#F38020',
  },
  
]

interface CaptchaPageProps {
  onNavigate: (page: string) => void
}

export function CaptchaPage({ onNavigate }: CaptchaPageProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [services, setServices] = useState(captchaServices)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const filteredServices = services.filter((service) =>
    service.name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const activeCount = services.filter((s) => s.isActive).length

  const handleToggle = (serviceName: string) => {
    setServices(prevServices =>
      prevServices.map(service =>
        service.name === serviceName
          ? { ...service, isActive: !service.isActive }
          : service
      )
    )
  }

  return (
    <>
      <header
        className={`w-[360px] px-4 py-3 border-b border-amber-100/30 bg-gradient-to-b from-amber-50/60 to-orange-50/40 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'}`}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('home')}
            className="w-8 h-8 text-amber-700 hover:text-amber-900 flex items-center justify-center"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="flex-1">
            <h1 className="text-sm font-semibold text-slate-900">Captcha Services</h1>
            <p className="text-[10px] text-amber-700/70">{activeCount} services enabled</p>
          </div>
          <div className="px-2 py-1 rounded-full bg-amber-100/60 text-amber-700 text-[10px] font-medium">
            <Shield className="w-3 h-3 inline mr-1" />
            Protected
          </div>
        </div>
      </header>

      <div className="px-4 py-3 border-b border-amber-100/30">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-600/60" />
          <input
            placeholder="Search services..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 h-9 bg-amber-50/50 border border-amber-200/40 rounded-lg focus:outline-none focus:border-amber-300 text-xs"
          />
        </div>
      </div>

      <div className="max-h-[380px] overflow-y-auto px-4 py-3 space-y-2">
        {filteredServices.map((service, index) => (
          <ExtensionCaptchaCard
            key={service.name}
            name={service.name}
            description={service.description}
            logo={service.icon}
            isPopular={service.isPopular}
            isActive={service.isActive}
            color={service.color}
            animationDelay={150 + index * 50}
            onToggle={() => handleToggle(service.name)}
          />
        ))}
      </div>

      <div className="px-4 py-3 border-t border-amber-100/30 bg-amber-50/40">
        <div className="flex items-center justify-between text-[10px]">
          <span className="text-amber-700">
            <span className="font-semibold">{activeCount}</span> of {captchaServices.length} enabled
          </span>
          <button className="text-amber-600 hover:text-amber-700 font-medium">Settings</button>
        </div>
      </div>
    </>
  )
}
