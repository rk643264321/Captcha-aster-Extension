"use client"

import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import {
  ArrowLeft,
  User,
  Mail,
  Calendar,
  CreditCard,
  LogOut,
  Crown,
  Zap,
  Shield,
  Copy,
  Check,
  ExternalLink,
  Chrome,
} from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ExtensionAccountPage() {
  const navigate = useNavigate()
  const [isVisible, setIsVisible] = useState(false)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const apiKey = "csk_live_a1b2c3d4e5f6g7h8i9j0"

  const copyApiKey = () => {
    navigator.clipboard.writeText(apiKey)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const accountStats = [
    { label: "Total Solved", value: "12,847", icon: Zap },
    { label: "Success Rate", value: "99.2%", icon: Shield },
    { label: "Member Since", value: "Jan 2024", icon: Calendar },
  ]

  return (
    <div className="dark:bg-gradient-to-b dark:from-gray-900 dark:to-gray-800 bg-gradient-to-b from-yellow-50/50 to-orange-50/30 ">
      <div className="w-[360px] dark:bg-gray-900 dark:border-gray-700 bg-white border border-yellow-100/40 shadow-lg overflow-hidden">
        {/* Header */}
        <header
          className={`px-4 py-3 dark:border-gray-700 dark:bg-gradient-to-b dark:from-gray-800 dark:to-gray-700 border-b border-yellow-100/30 bg-gradient-to-b from-yellow-50/60 to-orange-50/40 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-2"}`}
        >
          <div className="flex items-center gap-3">
            <Button 
              variant="ghost" 
              size="icon" 
              className="w-8 h-8 dark:text-orange-400 dark:hover:text-orange-300 text-orange-700 hover:text-orange-900"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-sm font-semibold dark:text-slate-100 text-slate-900">Account</h1>
          </div>
        </header>

        {/* Account Content */}
        <div className="max-h-[480px]">
          {/* Profile Section */}
          <div
            className={`px-4 py-4 dark:border-gray-700 border-b border-yellow-100/30 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "100ms" }}
          >
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-14 h-14 rounded-full dark:from-orange-900/20 dark:to-orange-800/10 dark:border-orange-700/30 bg-gradient-to-br from-orange-500/20 to-orange-400/10 flex items-center justify-center border-2 border-orange-300/30">
                  <User className="w-6 h-6 dark:text-orange-400 text-orange-600" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full dark:bg-orange-600 bg-orange-500 flex items-center justify-center">
                  <Crown className="w-3 h-3 text-white" />
                </div>
              </div>
              <div className="flex-1">
                <h2 className="text-sm font-semibold dark:text-slate-100 text-slate-900">John Doe</h2>
                <p className="text-xs dark:text-slate-400 text-slate-600 flex items-center gap-1">
                  <Mail className="w-3 h-3" />
                  john@example.com
                </p>
                <div className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-full dark:bg-orange-900/40 dark:text-orange-300 bg-orange-100/40 text-orange-700 text-[10px] font-medium">
                  <Crown className="w-3 h-3" />
                  Pro Plan
                </div>
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div
            className={`px-4 py-3 dark:border-gray-700 border-b border-yellow-100/30 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "200ms" }}
          >
            <div className="grid grid-cols-3 gap-2">
              {accountStats.map((stat, index) => (
                <div key={stat.label} className="text-center p-2.5 rounded-xl dark:bg-gray-800/30 bg-orange-50/30">
                  <stat.icon className="w-4 h-4 dark:text-orange-400 text-orange-600 mx-auto mb-1" />
                  <p className="text-sm font-bold dark:text-slate-100 text-slate-900">{stat.value}</p>
                  <p className="text-[9px] dark:text-slate-400 text-slate-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* API Key Section */}
          <div
            className={`px-4 py-3 dark:border-gray-700 border-b border-yellow-100/30 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "300ms" }}
          >
            <p className="text-xs font-medium dark:text-slate-100 text-slate-900 mb-2">API Key</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 px-3 py-2 rounded-lg dark:bg-gray-800/50 dark:text-slate-300 bg-orange-50/50 font-mono text-xs text-slate-600 truncate">
                {apiKey}
              </div>
              <Button variant="outline" size="icon" className="w-8 h-8 shrink-0 dark:bg-transparent dark:border-orange-700/50 bg-transparent border-orange-200/50" onClick={copyApiKey}>
                {copied ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
              </Button>
            </div>
          </div>

          {/* Subscription Section */}
          <div
            className={`px-4 py-3 dark:border-gray-700 border-b border-yellow-100/30 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "400ms" }}
          >
            <p className="text-xs font-medium dark:text-slate-100 text-slate-900 mb-2">Subscription</p>
            <div className="p-3 rounded-xl dark:from-orange-900/40 dark:to-gray-800/30 dark:border-orange-700/50 bg-gradient-to-r from-orange-100/40 to-orange-50/30 border border-orange-200/50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Crown className="w-4 h-4 dark:text-orange-400 text-orange-600" />
                  <span className="text-xs font-semibold dark:text-slate-100 text-slate-900">Pro Plan</span>
                </div>
                <span className="text-xs dark:text-orange-400 text-orange-700 font-medium">$19/mo</span>
              </div>
              <div className="flex items-center justify-between text-[10px] dark:text-slate-400 text-slate-600">
                <span>Renews on Feb 15, 2025</span>
                <span>50,000 credits/mo</span>
              </div>
              <div className="mt-2 h-1.5 rounded-full dark:bg-orange-900/50 bg-orange-100/50 overflow-hidden">
                <div className="h-full w-[65%] rounded-full dark:bg-orange-600 bg-orange-500" />
              </div>
              <p className="mt-1 text-[10px] dark:text-slate-400 text-slate-600">32,500 credits remaining</p>
            </div>
          </div>

          {/* Quick Links */}
          <div
            className={`px-4 py-3 transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
            style={{ transitionDelay: "500ms" }}
          >
            <div className="space-y-2">
              <button 
                className="w-full flex items-center justify-between py-2.5 px-3 rounded-lg dark:bg-gray-800/30 dark:hover:bg-gray-700/40 bg-orange-50/30 hover:bg-orange-100/40 transition-colors"
                onClick={() => navigate('/payment')}
              >
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 dark:text-slate-400 text-slate-600" />
                  <span className="text-xs dark:text-slate-100 text-slate-900">Manage Subscription</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5 dark:text-slate-400 text-slate-600" />
              </button>
              <button 
                className="w-full flex items-center justify-between py-2.5 px-3 rounded-lg dark:bg-red-900/20 dark:hover:bg-red-900/30 bg-red-500/10 hover:bg-red-500/20 transition-colors dark:text-red-400 text-red-600"
                onClick={() => {
                  // Add sign out logic here
                  console.log('Sign out clicked')
                  navigate('/')
                }}
              >
                <div className="flex items-center gap-2">
                  <LogOut className="w-4 h-4" />
                  <span className="text-xs font-medium">Sign Out</span>
                </div>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 dark:border-gray-700 dark:bg-gray-800/40 border-t border-yellow-100/30 bg-orange-50/40">
          <div className="flex items-center justify-center gap-1.5 text-[10px] dark:text-orange-400/70 text-orange-700/70">
            <Chrome className="w-3 h-3" />
            <span>Chrome Extension v2.4.1</span>
          </div>
        </div>
      </div>
    </div>
  )
}
