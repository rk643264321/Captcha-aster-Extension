'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft, Plus } from 'lucide-react'

interface TopupPageProps {
  onNavigate: (page: string) => void
}

export function TopupPage({ onNavigate }: TopupPageProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [selectedCredits, setSelectedCredits] = useState('5,000')

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const handleAddCredits = () => {
    // Redirect to website to add credits with selected amount
    const url = `https://captchasolver.com/add-credits?amount=${selectedCredits.replace(',', '')}`
    window.open(url, '_blank')
  }

  return (
    <div className="bg-gradient-to-b from-yellow-50/50 to-orange-50/30 p-1">
      <div className="w-[360px] bg-white border border-yellow-100/40 rounded-2xl shadow-lg overflow-hidden">
        {/* Header */}
        <header
          className={`px-4 py-3 border-b border-yellow-100/30 bg-gradient-to-b from-yellow-50/60 to-orange-50/40 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'}`}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="w-8 h-8 text-orange-700 hover:text-orange-900 flex items-center justify-center"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h1 className="text-sm font-semibold text-slate-900">Top Up Credits</h1>
          </div>
        </header>

        <div className="max-h-[420px] overflow-y-auto px-4 py-6">
          <div className="text-center space-y-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-orange-100/60 flex items-center justify-center mx-auto">
              <Plus className="w-8 h-8 text-orange-700" />
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-900">Add More Credits</h2>
              <p className="text-xs text-orange-700/70 mt-1">Choose an amount to add to your account</p>
            </div>
          </div>

          <div className="space-y-2">
            {[
              { credits: '1,000', price: '$2' },
              { credits: '5,000', price: '$9' },
              { credits: '10,000', price: '$16', save: 'Save 10%' },
              { credits: '50,000', price: '$75', save: 'Save 20%' },
            ].map((option, index) => (
              <button
                key={index}
                onClick={() => setSelectedCredits(option.credits)}
                className={`w-full p-3 rounded-lg border transition-all text-left ${
                  selectedCredits === option.credits
                    ? 'bg-orange-100/40 border-orange-300/50 ring-2 ring-orange-300/30'
                    : 'bg-orange-50/50 hover:bg-orange-100/40 border-orange-100/30'
                }`}
              >
                <div className="flex items-center">
                  <div className="w-4 h-4 rounded-full border-2 border-orange-300 flex items-center justify-center mr-3">
                    {selectedCredits === option.credits && (
                      <div className="w-2 h-2 rounded-full bg-orange-600" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs font-semibold text-slate-900">{option.credits} Credits</p>
                        {option.save && <p className="text-[9px] text-green-600 font-medium">{option.save}</p>}
                      </div>
                      <p className="text-sm font-bold text-orange-700">{option.price}</p>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="px-4 py-3 border-t border-yellow-100/30 bg-orange-50/40">
          <button 
            onClick={handleAddCredits}
            className="w-full py-2 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-medium transition-colors"
          >
            Add Credits to Website
          </button>
        </div>
      </div>
    </div>
  )
}
