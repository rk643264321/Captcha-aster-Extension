'use client'

import { useState, useEffect } from 'react'
import { ArrowLeft } from 'lucide-react'

interface PaymentPageProps {
  onNavigate: (page: string) => void
}

export function PaymentPage({ onNavigate }: PaymentPageProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="bg-gradient-to-b from-yellow-50/50 to-orange-50/30 p-1">
      <div className="w-[360px] bg-white border border-yellow-100/40 rounded-2xl shadow-lg overflow-hidden">
        {/* Header */}
        <header
          className={`px-4 py-3 border-b border-yellow-100/30 bg-gradient-to-b from-yellow-50/60 to-orange-50/40 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-2'}`}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="w-8 h-8 text-orange-700 hover:text-orange-900 flex items-center justify-center"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h1 className="text-sm font-semibold text-slate-900">Payment</h1>
          </div>
        </header>

        <div className="max-h-[420px] overflow-y-auto px-4 py-6">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-orange-100/60 flex items-center justify-center mx-auto">
              <svg className="w-8 h-8 text-orange-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h10m4 0a1 1 0 11-2 0m2 0a1 1 0 10-2 0m-4 0a1 1 0 11-2 0m2 0a1 1 0 10-2 0M3 5a2 2 0 012-2h14a2 2 0 012 2v4a1 1 0 01-1 1H4a1 1 0 01-1-1V5z" />
              </svg>
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-900">Choose Payment Plan</h2>
              <p className="text-xs text-orange-700/70 mt-1">Select a plan that suits your needs</p>
            </div>
          </div>

          <div className="mt-6 space-y-3">
            {[
              { name: 'Starter', price: '$9', credits: '5,000', perMonth: true },
              { name: 'Professional', price: '$19', credits: '50,000', perMonth: true, popular: true },
              { name: 'Enterprise', price: '$99', credits: '500,000', perMonth: true },
            ].map((plan) => (
              <button
                key={plan.name}
                className={`w-full p-3 rounded-lg border transition-all text-left ${
                  plan.popular
                    ? 'bg-orange-100/40 border-orange-300/50'
                    : 'bg-orange-50/30 border-orange-100/30 hover:border-orange-200/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-slate-900">{plan.name}</p>
                    <p className="text-[10px] text-orange-700/60">{plan.credits} credits</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-orange-700">{plan.price}</p>
                    {plan.perMonth && <p className="text-[9px] text-orange-700/60">/mo</p>}
                  </div>
                </div>
                {plan.popular && <div className="mt-2 px-2 py-0.5 rounded text-[9px] font-medium bg-orange-600/20 text-orange-700 w-fit">Popular</div>}
              </button>
            ))}
          </div>
        </div>

        <div className="px-4 py-3 border-t border-yellow-100/30 bg-orange-50/40">
          <button className="w-full py-2 rounded-lg bg-orange-600 hover:bg-orange-700 text-white text-xs font-medium transition-colors">
            Continue with Payment
          </button>
        </div>
      </div>
    </div>
  )
}
