import { useEffect } from "react";
import { ExtensionCaptchaServices } from "@/components/extension-captcha-services";
import { ExtensionStats } from "@/components/extension-stats";
import { ExtensionHeader } from "@/components/extension-header";
import { Chrome } from "lucide-react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { planRequest } from "@/store/auth";

interface HomePageProps {
  onLogout: () => void;
}

export function HomePage({ onLogout }: HomePageProps) {
  const dispatch = useAppDispatch();
  const { plan, planLoading } = useAppSelector(state => state.auth);

  // Fetch plan data on mount
  useEffect(() => {
    dispatch(planRequest());
  }, [dispatch]);

  return (
    <div className="dark:bg-gradient-to-b dark:from-gray-900 dark:to-gray-800 bg-gradient-to-b from-yellow-50/50 to-orange-50/30 ">
      {/* Extension popup container */}
      <div className="w-[360px] dark:bg-gray-900 dark:border-gray-700 bg-white border border-yellow-100/40  shadow-lg overflow-hidden">
        <ExtensionHeader />

        {/* Stats section with dark background */}
        <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
          <ExtensionStats userData={plan} />
        </div>

        <ExtensionCaptchaServices />

        {/* Footer */}
        <div className="px-5 py-3 dark:border-gray-700 border-t border-border dark:bg-gray-800/30 bg-secondary/30">
          <div className="flex items-center justify-center gap-1.5 text-[10px] text-muted-foreground">
            <Chrome className="w-3 h-3" />
            <span>Chrome Extension v2.4.1</span>
          </div>
        </div>
      </div>
    </div>
  );
}

