import { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { Provider } from "react-redux";

import { HomePage } from "./HomePage";


import { CaptchaPage } from "./pages/captcha";
import { PaymentPage } from "./pages/payment";
import { SettingsPage } from "./pages/settings";
import { TopupPage } from "./pages/topup";
import UpdatePage from "./pages/page";
import './style.css';
import ExtensionAccountPage from "./pages/account";
import ExtensionLoginPage from "./pages/login";
import { store } from "@/store";
import { useAppSelector, useAppDispatch } from "@/store/hooks";
import { authLogout, authCheck } from "@/store/auth/actions";

// Private Route Wrapper
const PrivateRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAppSelector(state => state.auth);

  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />;
};

// Public Route Wrapper
const PublicRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAppSelector(state => state.auth);

  return !isAuthenticated ? <>{children}</> : <Navigate to="/" replace />;
};

function AppContent() {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { isAuthenticated, loading } = useAppSelector(state => state.auth);

  // Check if user is logged in using stored auth data
  const ranOnce = useRef(false);

  useEffect(() => {
    if (ranOnce.current) return;
    ranOnce.current = true;

    dispatch(authCheck());
  }, []);


  const handleLogin = () => {
    ///setIsLoggedIn(true);
  };

  const handleLogout = () => {
    dispatch(authLogout({ navigate }));
  };



  const handleNavigate = (page: string) => {
    navigate(page);
  };

  return (
    <>
      <Toaster
        position='top-center'
        toastOptions={{
          duration: 4000,


        }}
      />

      <Routes>
        <Route path="/login" element={<PublicRoute> <ExtensionLoginPage onLogin={handleLogin} /> </PublicRoute>} />
        <Route path="/" element={<PrivateRoute> <HomePage onLogout={handleLogout} />  </PrivateRoute>} />
        <Route path="/account" element={<PrivateRoute> <ExtensionAccountPage />  </PrivateRoute>} />
        <Route path="/captcha" element={<PrivateRoute>  <CaptchaPage onNavigate={handleNavigate} />   </PrivateRoute>} />
        <Route path="/payment" element={<PrivateRoute>  <PaymentPage onNavigate={handleNavigate} /> </PrivateRoute>} />
        <Route path="/settings" element={<PrivateRoute>   <SettingsPage onNavigate={handleNavigate} />  </PrivateRoute>} />
        <Route path="/topup" element={<PrivateRoute>   <TopupPage onNavigate={handleNavigate} />  </PrivateRoute>} />
        <Route path="/update" element={<PrivateRoute>   <UpdatePage />  </PrivateRoute>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}

function App() {
  return (
    <Provider store={store}>
      <Router>
        <AppContent />
      </Router>
    </Provider>
  );
}

export default App;
