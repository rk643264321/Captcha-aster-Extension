import toast from "react-hot-toast";
import iconUrl from '@/assets/icon.png';



export default defineContentScript({
  matches: ['*://*.kolotibablo.com/*'],
  cssInjectionMode: 'ui', // ⭐ must
  main() {

    let toastEl: HTMLDivElement | null = null;
    let toastHideTimer: number | undefined;

    function injectToastStyle() {
      if (document.getElementById('cm-toast-style-binance')) return;
      const style = document.createElement('style');
      style.id = 'cm-toast-style-binance';
      style.textContent = `
                @keyframes cm-toast-slide-in {
                    from { opacity: 0; transform: translateX(120%) scale(0.9); }
                    to { opacity: 1; transform: translateX(0) scale(1); }
                }
                .cm-toast-binance {
                    position: fixed !important; 
                    top: 24px !important; 
                    right: 24px !important; 
                    bottom: auto !important; 
                    left: auto !important;
                    z-index: 2147483647 !important;
                    min-width: 320px; padding: 16px 20px; border-radius: 12px;
                    background: rgba(30, 35, 41, 0.95); backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.08); color: #eaecef;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.4); font-family: sans-serif;
                    display: flex; align-items: center; gap: 12px; overflow: hidden;
                    animation: cm-toast-slide-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                .cm-toast-icon { width: 22px; height: 22px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: 6px; background: rgba(255,255,255,0.05); }
                .cm-toast-content { flex: 1; }
                .cm-toast-title { font-weight: 600; font-size: 14px; color: #fff; margin-bottom: 2px; }
                .cm-toast-msg { font-size: 12px; color: #b7bdc6; }
                .cm-toast-progress-track { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: rgba(255,255,255,0.05); }
                .cm-toast-progress { height: 100%; width: 100%; transform-origin: left; transform: scaleX(1); }
                .cm-toast-binance.success .cm-toast-icon { color: #0ecb81; }
                .cm-toast-binance.success .cm-toast-progress { background: #0ecb81; }
                .cm-toast-binance.warn .cm-toast-icon { color: #f0b90b; }
                .cm-toast-binance.warn .cm-toast-progress { background: #f0b90b; }
                .cm-toast-binance.error .cm-toast-icon { color: #f6465d; }
                .cm-toast-binance.error .cm-toast-progress { background: #f6465d; }
                .cm-toast-binance.info .cm-toast-icon { color: #3b82f6; }
                .cm-toast-binance.info .cm-toast-progress { background: #3b82f6; }

                /* Premium Detection & Selection Effects */
                .cm-detecting {
                    position: relative;
                    outline: 2px solid #f0b90b !important;
                    outline-offset: -2px;
                    box-shadow: 0 0 20px rgba(240, 185, 11, 0.4) !important;
                    filter: brightness(1.1);
                    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                }
                .cm-selected {
                    outline: 2px solid #0ecb81 !important;
                    outline-offset: -2px;
                    box-shadow: 0 0 20px rgba(14, 203, 129, 0.4) !important;
                    filter: brightness(1.1);
                    transform: scale(0.98);
                    transition: all 0.2s ease;
                }
                @keyframes cm-pulse {
                    0% { opacity: 0.6; }
                    50% { opacity: 1; }
                    100% { opacity: 0.6; }
                }
            `;
      document.head.appendChild(style);
    }

    function showToast(title: string, msg: string, variant: 'success' | 'warn' | 'error' | 'info' = 'success') {
      const timeoutMs = 5000;
      injectToastStyle();
      if (toastEl) toastEl.remove();

      toastEl = document.createElement('div');
      toastEl.className = `cm-toast-binance ${variant}`;
      toastEl.innerHTML = `
                <div class="cm-toast-icon">${variant === 'success' ? '⚡' : '⚠️'}</div>
                <div class="cm-toast-content">
                    <div class="cm-toast-title">${title}</div>
                    <div class="cm-toast-msg">${msg}</div>
                </div>
                <div class="cm-toast-progress-track">
                    <div class="cm-toast-progress"></div>
                </div>
            `;
      document.body.appendChild(toastEl);

      const progressEl = toastEl.querySelector('.cm-toast-progress') as HTMLElement;
      setTimeout(() => {
        progressEl.style.transition = `transform ${timeoutMs}ms linear`;
        progressEl.style.transform = 'scaleX(0)';
      }, 10);

      clearTimeout(toastHideTimer);
      toastHideTimer = window.setTimeout(() => {
        toastEl?.remove();
        toastEl = null;
      }, timeoutMs);
    }



    function addImageDetectionEffect() {
      const img = document.querySelector('img.gr-image[src^="data:image"]') as HTMLImageElement;
      if (img) {
        console.log('Captcha image detected');
        img.classList.add('cm-detecting');
        setTimeout(() => img.classList.remove('cm-detecting'), 2000);
      }
    }


    let lastCaptchaSrc = '';

    function detectCaptcha() {
      const img = document.querySelector(
        'img.gr-image[src^="data:image"]'
      ) as HTMLImageElement | null;

      if (!img || !img.src) return;

      if (img.src === lastCaptchaSrc) return;

      lastCaptchaSrc = img.src;

      if (!serviceEnabled) {
        showToast('Service Inactive ⚠️', 'Please enable "Kolotibablo Login" in extension settings to auto-solve.', 'warn');
        console.log('🚫 Captcha found but service is disabled');
        return;
      }

      showToast('Captcha Detected 🔍', 'Starting auto-solving process...', 'info');

      const question =
        document.querySelector('.captcha-info strong')?.textContent?.trim() || '';

      browser.runtime.sendMessage({
        type: 'CAPTCHA_IMAGE',
        imageData: img.src,
        question,
        questionType: "objectClassify"
      });

      addImageDetectionEffect();
    }

    const CONFIG_KEY = 'config_services';
    let serviceEnabled = false;

    const updateEnabledStatus = async () => {
      try {
        const result: any = await browser.storage.local.get(CONFIG_KEY);
        const newState = Boolean(result?.[CONFIG_KEY]?.['Kolotibablo Login']?.enable);

        // If transitioning from false to true, clear last source to trigger re-detection
        if (!serviceEnabled && newState) {
          lastCaptchaSrc = '';
        }

        serviceEnabled = newState;
        console.log('🔄 Kolotibablo service status:', serviceEnabled ? 'ENABLED' : 'DISABLED');
        detectCaptcha();
      } catch (e) {
        console.error('Failed to get storage:', e);
      }
    };

    updateEnabledStatus();

    // Listen for storage changes
    browser.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[CONFIG_KEY]) {
        updateEnabledStatus();
      }
    });

    let detectTimeout: number | undefined;
    const debouncedDetect = () => {
      clearTimeout(detectTimeout);
      detectTimeout = window.setTimeout(() => {
        if (serviceEnabled) detectCaptcha();
      }, 50);
    };

    // 🔍 Observe DOM changes
    const observer = new MutationObserver(() => {
      debouncedDetect();
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    ///tac fontbold error marginbottom10

    // first manual check
    updateEnabledStatus();

    // Fallback polling for speed (every 1s)
    setInterval(() => {
      detectCaptcha();
    }, 1000);

    // ===== HANDLE SOLVER RESPONSE =====
    browser.runtime.onMessage.addListener(async (message) => {

      if (message.type === 'api_error') {
        showToast(message.error || 'API error occurred', 'error');
        return;
      }

      if (!serviceEnabled) return;


      const cells = document.querySelectorAll(
        '.captcha-widget .cell'
      ) as NodeListOf<HTMLElement>;

      const verifyBtn = document.querySelector(
        'button.btn.btn-primary'
      ) as HTMLElement | null;

      const solution = message.solution;




      if (!Array.isArray(solution) || solution.length === 0) {
        console.log('⏭ Empty → next captcha');
        showToast('Empty answer. Skipping...', 'warn');

        setTimeout(() => {
          verifyBtn?.click();
        }, 2000);

        return;
      }

      // Select cells with animation delay
      solution.forEach((i: number, index: number) => {
        setTimeout(() => {
          const cell = cells[i - 1];
          if (cell) {
            cell.click();
            cell.classList.add('cm-selected');
          }
        }, index * 150); // Stagger the selections
      });

      const selectionDelay = solution.length * 150 + 500;

      setTimeout(() => {
        showToast('Submitting answer...', 'info');
      }, selectionDelay);

      setTimeout(() => {
        verifyBtn?.click();
        showToast('Answer submitted successfully!', 'success');

        // Clean up selected classes
        cells.forEach(cell => cell.classList.remove('cm-selected'));
      }, selectionDelay + 800);


    });
  },
});
