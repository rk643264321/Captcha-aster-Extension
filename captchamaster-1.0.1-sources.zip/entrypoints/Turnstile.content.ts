export default defineContentScript({
  matches: [
    '*://challenges.cloudflare.com/*',
    '*://*.cloudflare.com/*',
    '*://*.turnstile.com/*',
    '*://turnstile.cloudflare.com/*'
  ],
  main() {
   
  
      
  },
});