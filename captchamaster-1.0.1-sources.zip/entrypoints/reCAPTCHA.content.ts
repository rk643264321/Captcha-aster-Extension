export default defineContentScript({
  matches: [

    '*://www.gstatic.com/recaptcha/*'
  ],
  main() {
    console.log('reCAPTCHA content script loaded');
  
  },
});