import { useDispatch } from 'react-redux'
import {
    alertSuccess,
    alertError,
    alertInfo,
    alertWarning,
    alertLoading,
    alertClearAll
} from '@/store'

/**
 * Demo component showing how to use the alert system
 * This is an example component - you can delete it after understanding the usage
 */
export const AlertDemo = () => {
    const dispatch = useDispatch()

    return (
        <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
            <h2>Alert System Demo</h2>
            <p>Click the buttons below to test different alert types:</p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '20px' }}>
                <button
                    onClick={() => dispatch(alertSuccess('Operation completed successfully!'))}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#10b981',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '500'
                    }}
                >
                    Show Success Alert
                </button>

                <button
                    onClick={() => dispatch(alertError('Something went wrong!'))}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#ef4444',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '500'
                    }}
                >
                    Show Error Alert
                </button>

                <button
                    onClick={() => dispatch(alertInfo('Here is some useful information'))}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#3b82f6',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '500'
                    }}
                >
                    Show Info Alert
                </button>

                <button
                    onClick={() => dispatch(alertWarning('Please be careful!'))}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#f59e0b',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '500'
                    }}
                >
                    Show Warning Alert
                </button>

                <button
                    onClick={() => dispatch(alertLoading('Loading data...'))}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#6366f1',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '500'
                    }}
                >
                    Show Loading Alert
                </button>

                <button
                    onClick={() => {
                        dispatch(alertSuccess('This will show for 10 seconds', 10000))
                    }}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#8b5cf6',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '500'
                    }}
                >
                    Show Long Duration Alert (10s)
                </button>

                <button
                    onClick={() => dispatch(alertClearAll())}
                    style={{
                        padding: '10px 20px',
                        backgroundColor: '#6b7280',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        cursor: 'pointer',
                        fontSize: '14px',
                        fontWeight: '500',
                        marginTop: '10px'
                    }}
                >
                    Clear All Alerts
                </button>
            </div>

            <div style={{ marginTop: '30px', padding: '15px', backgroundColor: '#f3f4f6', borderRadius: '8px' }}>
                <h3 style={{ marginTop: 0 }}>Usage Example:</h3>
                <pre style={{
                    backgroundColor: '#1f2937',
                    color: '#f9fafb',
                    padding: '15px',
                    borderRadius: '6px',
                    overflow: 'auto',
                    fontSize: '12px'
                }}>
                    {`import { useDispatch } from 'react-redux'
import { alertSuccess } from '@/store'

function MyComponent() {
  const dispatch = useDispatch()
  
  const handleClick = () => {
    dispatch(alertSuccess('Success!'))
  }
  
  return <button onClick={handleClick}>Click me</button>
}`}
                </pre>
            </div>
        </div>
    )
}

export default AlertDemo
