"use client"

import { useState, useEffect } from "react"
import { RotateCcw, Calendar, TrendingUp } from "lucide-react"

/* =========================
   Types
========================= */
interface UserPlan {
  dailyLimit?: number
  dailyLimitUsed?: number
  refill?: number // Unix timestamp in seconds
  end?: number    // Unix timestamp in seconds
}

interface UserData {
  _id?: string
  userId?: string
  packageCode?: string
  type?: string
  name?: string
  price?: number
  billingCycle?: string
  credits?: number
  creditsUsed?: number
  features?: string[]
  status?: string
  autoRenew?: boolean
  startDate?: string
  endDate?: string
  createdAt?: string
  updatedAt?: string
  __v?: number
  plan?: UserPlan
}

interface ExtensionStatsProps {
  userData?: UserData
}

/* =========================
   Mock Data
========================= */
const mockUserData: UserData = {
  "_id": "6988645d72c7e09865a6c60e",
  "userId": "6988645c72c7e09865a6c60c",
  "packageCode": "TRIAL",
  "type": "count",
  "name": "Free Trial",
  "price": 0,
  "billingCycle": "monthly",
  "credits": 100,
  "creditsUsed": 0,
  "features": [
    "100 Free Requests",
    "Trial Access",
    "3 Days Validity"
  ],
  "status": "active",
  "autoRenew": false,
  "startDate": "2026-02-08T10:24:29.167Z",
  "endDate": "2026-02-11T10:24:29.166Z",
  "createdAt": "2026-02-08T10:24:29.170Z",
  "updatedAt": "2026-02-08T10:24:29.170Z",
  "__v": 0,
  "plan": {
    "dailyLimit": 100,
    "dailyLimitUsed": 15,
    "refill": Math.floor(Date.now() / 1000) + 3600 * 5, // 5 hours from now
    "end": Math.floor(Date.now() / 1000) + 86400 * 3    // 3 days from now
  }
}

/* =========================
   Component
========================= */
export function ExtensionStats({ userData = mockUserData }: ExtensionStatsProps) {
  const [isVisible, setIsVisible] = useState(false)
  const [refillTime, setRefillTime] = useState<string>("00:00:00:00")
  const [expiresTime, setExpiresTime] = useState<string>("00:00:00:00")

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 200)
    return () => clearTimeout(timer)
  }, [])

  /**
   * Calculate time remaining from timestamps or ISO strings
   */
  const calculateTimeRemaining = (time: number | string | undefined): string => {
    if (!time) return "00:00:00:00"

    const now = Math.floor(Date.now() / 1000)
    let diff: number

    if (typeof time === "string") {
      diff = Math.floor(new Date(time).getTime() / 1000) - now
    } else {
      diff = time - now
    }

    if (diff <= 0) return "00:00:00:00"

    const days = Math.floor(diff / 86400)
    diff %= 86400

    const hours = Math.floor(diff / 3600)
    diff %= 3600

    const minutes = Math.floor(diff / 60)
    const seconds = diff % 60

    return `${String(days).padStart(2, "0")}:${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`
  }

  // Real-time countdown update
  useEffect(() => {
    const updateTimers = () => {
      // Use plan data if available, fallback to root level data
      const refillTarget = userData?.plan?.refill
      const expiresTarget = userData?.plan?.end || userData?.endDate

      setRefillTime(calculateTimeRemaining(refillTarget))
      setExpiresTime(calculateTimeRemaining(expiresTarget))
    }

    updateTimers() // Initial update
    const countdown = setInterval(updateTimers, 1000)
    return () => clearInterval(countdown)
  }, [userData])

  // Modern vibrant border colors based on time remaining
  const getRefillBorderColor = () => {
    const timeParts = refillTime.split(':').map(Number)
    const totalSeconds = timeParts[0] * 86400 + timeParts[1] * 3600 + timeParts[2] * 60 + timeParts[3]
    if (totalSeconds === 0) return "border-slate-300 dark:border-slate-700/50"
    if (totalSeconds < 1800) return "border-red-400/60 dark:border-red-500/50 shadow-[0_0_8px_rgba(239,68,68,0.15)]"
    if (totalSeconds < 3600) return "border-amber-400/60 dark:border-amber-500/50"
    return "border-blue-400/60 dark:border-blue-500/40"
  }

  const getExpiresBorderColor = () => {
    const timeParts = expiresTime.split(':').map(Number)
    const totalSeconds = timeParts[0] * 86400 + timeParts[1] * 3600 + timeParts[2] * 60 + timeParts[3]
    if (totalSeconds === 0) return "border-slate-300 dark:border-slate-700/50"
    if (totalSeconds < 3600) return "border-red-400/60 dark:border-red-500/50 shadow-[0_0_8px_rgba(239,68,68,0.15)]"
    if (totalSeconds < 86400) return "border-amber-400/60 dark:border-amber-500/50"
    return "border-orange-400/60 dark:border-orange-500/40"
  }

  return (
    <div className={`px-5 py-4 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
      <div className="flex gap-3">
        {/* Daily Limit / Usage */}
        <div className="flex-1 px-3 py-2.5 rounded-lg bg-violet-50 dark:bg-slate-800/40 border border-violet-200/60 dark:border-slate-700/50 hover:border-violet-400/60 dark:hover:border-slate-600/60 transition-all group">
          <div className="flex items-center gap-1.5 mb-2">
            <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span className="text-[10px] font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-widest">USAGE</span>
          </div>
          <div className="flex items-baseline gap-1">
            <p className="text-lg font-bold text-slate-900 dark:text-white leading-none">
              {userData?.plan?.dailyLimitUsed ?? userData?.creditsUsed ?? 0}
            </p>
            <span className="text-xs text-slate-400 dark:text-slate-500 font-medium">/</span>
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              {userData?.plan?.dailyLimit ?? userData?.credits ?? 0}
            </p>
          </div>
        </div>

        {/* Next Reset Countdown - Only show for non-count types */}
        {userData?.type !== "count" && (
          <div className={`flex-1 px-3 py-2.5 rounded-lg bg-blue-50 dark:bg-slate-800/40 border transition-all duration-300 ${getRefillBorderColor()} group`}>
            <div className="flex items-center gap-1.5 mb-2">
              <RotateCcw className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 group-hover:rotate-180 transition-transform duration-500" />
              <span className="text-[10px] font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-widest">RESET</span>
            </div>
            <p className="text-base font-bold text-slate-900 dark:text-white font-mono tracking-tight leading-none">{refillTime}</p>
          </div>
        )}

        {/* Expiration Countdown */}
        <div className={`flex-1 px-3 py-2.5 rounded-lg bg-orange-50 dark:bg-slate-800/40 border transition-all duration-300 ${getExpiresBorderColor()} group`}>
          <div className="flex items-center gap-1.5 mb-2">
            <Calendar className="w-3.5 h-3.5 text-orange-600 dark:text-orange-400 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-widest">EXPIRE</span>
          </div>
          <p className="text-base font-bold text-slate-900 dark:text-white font-mono tracking-tight leading-none">{expiresTime}</p>
        </div>
      </div>
    </div>
  )
}

