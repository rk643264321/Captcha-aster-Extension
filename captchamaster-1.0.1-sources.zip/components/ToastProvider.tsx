import { Toaster } from 'react-hot-toast'

/**
 * ToastProvider component that wraps the react-hot-toast Toaster
 * This should be added to your app's root component
 */
export const ToastProvider = () => {
    return (
        <Toaster
            position="top-right"
            reverseOrder={false}
            gutter={8}
            toastOptions={{
                // Default options
                duration: 4000,
                style: {
                    background: '#363636',
                    color: '#fff',
                    borderRadius: '8px',
                    padding: '16px',
                },
                // Success
                success: {
                    duration: 3000,
                    iconTheme: {
                        primary: '#10b981',
                        secondary: '#fff',
                    },
                    style: {
                        background: '#10b981',
                        color: '#fff',
                    },
                },
                // Error
                error: {
                    duration: 5000,
                    iconTheme: {
                        primary: '#ef4444',
                        secondary: '#fff',
                    },
                    style: {
                        background: '#ef4444',
                        color: '#fff',
                    },
                },
                // Loading
                loading: {
                    iconTheme: {
                        primary: '#3b82f6',
                        secondary: '#fff',
                    },
                    style: {
                        background: '#3b82f6',
                        color: '#fff',
                    },
                },
            }}
        />
    )
}

export default ToastProvider
