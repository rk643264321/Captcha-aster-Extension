import { useState, useEffect } from 'react'
import { Shield, Zap, Lock, Cpu, Puzzle, Eye, Clock, AlertCircle } from 'lucide-react'
import { getStorageData, setStorageData } from '@/lib/storage'
import { Switch } from "@/components/ui/switch"


/* =========================
   Types
========================= */
type ServiceStatus = 'available' | 'coming-soon' | 'suspended'

interface ServiceConfigItem {
  name: string
  enable: boolean
}

type ServiceConfig = Record<string, ServiceConfigItem>

/* =========================
   Constants
========================= */
const CONFIG_KEY = 'config_services'

/* =========================
   Services
========================= */
const initialServices = [

  {
    name: 'Kolotibablo Login',
    description: 'Kolotibablo.com Login',
    icon: <Lock className="w-5 h-5 text-green-500" />,
    color: '#10B981',
    isPopular: true,
    animationDelay: 350,
    status: 'available' as ServiceStatus,
  },
    {
    name: 'Auto Worker',
    description: 'Auto redirect to earn page',
    icon: <Cpu className="w-5 h-5 text-purple-500" />,
    color: '#A855F7',
    isPopular: false,
    animationDelay: 50,
    status: 'available' as ServiceStatus,
  },
  {
    name: 'POPULARCAPTCHA',
    description: 'POPULARCAPTCHA',
    icon: <Zap className="w-5 h-5 text-yellow-500" />,
    color: '#FBBF24',
    isPopular: false,
    animationDelay: 75,
    status: 'coming-soon' as ServiceStatus,
  },
  {
    name: 'reCAPTCHA v2',
    description: 'Google reCAPTCHA v2',
    icon: <Zap className="w-5 h-5 text-yellow-600" />,
    color: '#F59E0B',
    isPopular: false,
    animationDelay: 100,
    status: 'coming-soon' as ServiceStatus,
  },
  {
    name: 'AWS WAF',
    description: 'Amazon Web Services WAF',
    icon: <Shield className="w-5 h-5 text-orange-500" />,
    color: '#F97316',
    isPopular: false,
    animationDelay: 250,
    status: 'coming-soon' as ServiceStatus,
  },
  {
    name: 'GeeTest',
    description: 'GeeTest captcha solver',
    icon: <Puzzle className="w-5 h-5 text-blue-500" />,
    color: '#3B82F6',
    isPopular: false,
    animationDelay: 275,
    status: 'coming-soon' as ServiceStatus,
  },
  {
    name: 'Turnstile',
    description: 'Cloudflare Turnstile',
    icon: <Cpu className="w-5 h-5 text-cyan-500" />,
    color: '#06B6D4',
    isPopular: false,
    animationDelay: 225,
    status: 'suspended' as ServiceStatus,
  },
  {
    name: 'ProsoPo',
    description: 'ProsoPo captcha solver',
    icon: <Eye className="w-5 h-5 text-indigo-500" />,
    color: '#6366F1',
    isPopular: false,
    animationDelay: 300,
    status: 'coming-soon' as ServiceStatus,
  },
  {
    name: 'Friendly Captcha',
    description: 'Friendly Captcha solver',
    icon: <Shield className="w-5 h-5 text-teal-500" />,
    color: '#14B8A6',
    isPopular: false,
    animationDelay: 325,
    status: 'coming-soon' as ServiceStatus,
  },
  {
    name: 'FunCaptcha',
    description: 'Arkose Labs FunCaptcha',
    icon: <Puzzle className="w-5 h-5 text-pink-500" />,
    color: '#EC4899',
    isPopular: true,
    animationDelay: 350,
    status: 'coming-soon' as ServiceStatus,
  },


  {
    name: 'Auto Play',
    description: 'Auto click play button',
    icon: <Zap className="w-5 h-5 text-orange-500" />,
    color: '#F97316',
    isPopular: false,
    animationDelay: 0,
    status: 'suspended' as ServiceStatus,
  },

]

/* =========================
   Internal Components
========================= */
interface InternalCardProps {
  name: string
  description: string
  logo: React.ReactNode
  isPopular?: boolean
  isActive?: boolean
  color: string
  animationDelay?: number
  status?: ServiceStatus
  onToggle?: (name: string, isEnabled: boolean) => void
}

function InternalCaptchaCard({
  name,
  description,
  logo,
  isPopular = false,
  isActive = false,
  color,
  animationDelay = 0,
  status = 'available',
  onToggle,
}: InternalCardProps) {
  const [enabled, setEnabled] = useState(isActive)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setEnabled(isActive)
  }, [isActive])

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), animationDelay)
    return () => clearTimeout(timer)
  }, [animationDelay])

  const handleToggle = (checked: boolean) => {
    setEnabled(checked)
    onToggle?.(name, checked)
  }

  const getStatusBadge = () => {
    

    switch (status) {
      case 'coming-soon':
        return (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full dark:bg-amber-900/50 dark:text-amber-300 bg-amber-100 text-[9px] font-medium text-amber-700">
            <Clock className="w-3 h-3" />
            Coming Soon
          </div>
        )
      case 'suspended':
        return (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full dark:bg-red-900/50 dark:text-red-300 bg-red-100 text-[9px] font-medium text-red-700">
            <AlertCircle className="w-3 h-3" />
            Deactivated
          </div>
        )
      default:
        return null
    }
  }

  const isDisabled = status !== 'available'

  return (
    <div
      className={`relative p-3 rounded-xl border transition-all duration-300 ${isDisabled
        ? "dark:bg-slate-800/20 dark:border-slate-800 bg-muted/30 border-muted/50 opacity-60"
        : enabled
          ? "dark:bg-emerald-500/10 dark:border-emerald-500/40 bg-emerald-50/50 border-emerald-500/30"
          : "dark:bg-slate-800/30 dark:border-slate-700/50 dark:hover:border-emerald-500/30 bg-secondary/10 border-border hover:border-emerald-500/20"
        } ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
    >
      <div className="absolute -top-2 right-3 flex gap-1">
        {isPopular && (
          <div className="px-2 py-0.5 rounded-full dark:bg-emerald-600/80 dark:text-white bg-emerald-600 text-[9px] font-medium text-primary-foreground">
            Popular
          </div>
        )}
        {getStatusBadge()}
      </div>

      <div className="flex items-center gap-3">
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: `${color}15` }}
        >
          {logo}
        </div>

        <div className="flex-1 min-w-0">
          <h3 className="text-[11px] font-semibold text-foreground truncate">{name}</h3>
          <p className="text-[10px] text-muted-foreground truncate">{description}</p>
        </div>

        <Switch
          checked={isDisabled ? false : enabled}
          disabled={isDisabled}
          onCheckedChange={handleToggle}
          className={`${isDisabled ? 'opacity-40 cursor-not-allowed' : 'data-[state=checked]:bg-emerald-500'} shrink-0 h-4 w-7 [&>span]:h-3 [&>span]:w-3`}
        />
      </div>
    </div>
  )
}

/* =========================
   Component
========================= */
export function ExtensionCaptchaServices() {

  const [isVisible, setIsVisible] = useState(false)
  const [serviceStates, setServiceStates] = useState<Record<string, boolean>>({})

  /* =========================
     Init & Load Config
  ========================= */
  useEffect(() => {
    const initConfig = async () => {
      let config: ServiceConfig = await getStorageData(CONFIG_KEY, {})

      let changed = false

      for (const service of initialServices) {
        if (!config[service.name]) {
          config[service.name] = {
            name: service.name,
            enable: service.status === 'available',
          }
          changed = true
        } else {
          // If status is not available, force it to be disabled
          if (service.status !== 'available' && config[service.name].enable) {
            config[service.name].enable = false
            changed = true
          }
        }
      }

      if (changed) {
        await setStorageData(CONFIG_KEY, config)
      }

      const states: Record<string, boolean> = {}
      Object.values(config).forEach((s) => {
        states[s.name] = s.enable
      })

      setServiceStates(states)
    }

    initConfig()

    const timer = setTimeout(() => setIsVisible(true), 300)
    return () => clearTimeout(timer)
  }, [])

  /* =========================
     Toggle Handler
  ========================= */
  const handleToggle = async (serviceName: string, isEnabled: boolean) => {
    const config: ServiceConfig = await getStorageData(CONFIG_KEY, {})

    if (!config[serviceName]) return

    config[serviceName].enable = isEnabled

    await setStorageData(CONFIG_KEY, config)

    setServiceStates((prev) => ({
      ...prev,
      [serviceName]: isEnabled,
    }))
  }

  /* =========================
     Render
  ========================= */
  return (
    <div className="px-4 py-4 dark:bg-gray-900 bg-white">
      <div
        className={`transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
      >
        <p className="text-xs font-semibold dark:text-slate-300 text-slate-700 mb-3 uppercase tracking-wide">
          Captcha Services
        </p>

        <div className="grid grid-cols-1 gap-2">
          {initialServices.map((service) => (
            <InternalCaptchaCard
              key={service.name}
              name={service.name}
              description={service.description}
              logo={service.icon}
              isPopular={service.isPopular}
              isActive={serviceStates[service.name]}
              color={service.color}
              animationDelay={service.animationDelay}
              status={service.status}
              onToggle={handleToggle}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
