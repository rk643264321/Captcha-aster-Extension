"use client"

import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { Settings, User, Power, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { getStorageData, setStorageData } from "@/lib/storage"
import { authLogout } from "@/store"
import { useDispatch } from "react-redux"
import logo from "@/assets/icon.png"


export function ExtensionHeader() {
  const navigate = useNavigate()
  const [isEnabled, setIsEnabled] = useState(true)
  const [isVisible, setIsVisible] = useState(false)
  const dispatch = useDispatch()

  // Load state from Chrome storage on mount
  useEffect(() => {
    const loadState = async () => {
      const stored = await getStorageData('extensionEnabled', true)
      setIsEnabled(stored)
    }
    loadState()
  }, [])

  // Save state to Chrome storage when changed
  const handleToggle = async (checked: boolean) => {
    await setStorageData('extensionEnabled', checked);

    setIsEnabled(checked)
  }

  // Handle logout
  const handleLogout = async () => {
    dispatch(authLogout({ navigate }));
  }

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  return (
    <header
      className={`px-4 py-3 border-b border-border bg-card transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-2"}`}
    >
      <div className="flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="relative w-8 h-8 rounded-lg overflow-hidden bg-gradient-to-br  flex items-center justify-center shadow-sm">
            <img
              src={logo}
              alt="CaptchaMaster Logo"
              className="w-full h-full object-cover"
            />
            <div className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-card shadow-sm" />
          </div>


          <div>
            <h1 className="text-sm font-semibold dark:text-white text-black">
              Captcha<span className="text-yellow-500">Ɱaster</span>
            </h1>
            <p className="text-[10px] text-muted-foreground">v1.0.1</p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-secondary/50">
            <Power className={`w-3 h-3 ${isEnabled ? "text-green-500" : "text-muted-foreground"}`} />
            <Switch
              checked={isEnabled}
              onCheckedChange={handleToggle}
              className="scale-75 data-[state=checked]:bg-emerald-500"
            />
          </div>



          <Button
            variant="ghost"
            size="icon"
            className="w-7 h-7 text-muted-foreground hover:text-foreground"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </header>
  )
}
