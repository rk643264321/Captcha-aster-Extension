import { Chrome } from "lucide-react";
import "./loading.css";

export default function Loading() {
  return (
    <div className="h-[600px] w-[360px] bg-background dark:bg-gray-900 flex items-center justify-center overflow-hidden relative">
      {/* Animated background orbs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-80 h-80 bg-primary/10 dark:bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-1/3 -right-32 w-72 h-72 bg-accent/8 dark:bg-accent/15 rounded-full blur-3xl animate-float" style={{ animationDelay: '0.5s' }} />
      </div>

      {/* Main content */}
      <div className="relative z-10 flex flex-col items-center gap-6 px-4">
        {/* Company branding */}
        <div className="flex flex-col items-center gap-3">
          <h1 className="text-2xl font-bold text-foreground dark:text-slate-100">
            Captcha<span className="text-primary">Ɱaster</span>
          </h1>
          <p className="text-xs uppercase tracking-widest text-muted-foreground dark:text-slate-400">
            Solver
          </p>
        </div>

        {/* Smiley face loader */}
        <div className="relative w-24 h-24 flex items-center justify-center">
          <svg className="w-full h-full" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r="55" fill="none" stroke="currentColor" strokeWidth="2" className="text-secondary/20" />
            <circle cx="40" cy="45" r="4" fill="currentColor" className="text-primary" />
            <circle cx="80" cy="45" r="4" fill="currentColor" className="text-primary" />
            <path
              d="M 40 70 Q 60 85 80 70"
              stroke="currentColor"
              strokeWidth="4"
              fill="none"
              strokeLinecap="round"
              className="text-primary"
              style={{
                animation: 'smile 1.5s ease-in-out infinite',
                transformOrigin: '60px 60px'
              }}
            />
          </svg>
        </div>

        {/* Loading text */}
        <div className="text-center space-y-1">
          <h2 className="text-lg font-semibold text-foreground dark:text-slate-100">Loading</h2>
          <p className="text-sm text-muted-foreground dark:text-slate-400">Setting up...</p>
        </div>

        {/* Status dots */}
        <div className="flex gap-2">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-2 h-2 rounded-full bg-muted-foreground/40 dark:bg-slate-400/40"
              style={{
                animation: 'pulse 1.4s ease-in-out infinite',
                animationDelay: `${i * 0.2}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-0 left-0 right-0 px-5 py-3 dark:border-gray-700 dark:bg-gray-800/30 border-t border-border bg-secondary/30">
        <div className="flex items-center justify-center gap-1.5 text-[10px] dark:text-slate-400 text-muted-foreground">
         <Chrome className="w-3 h-3" />
          <span>Chrome Extension v2.4.1</span>
        </div>
      </div>
 
    </div>
  )
}
