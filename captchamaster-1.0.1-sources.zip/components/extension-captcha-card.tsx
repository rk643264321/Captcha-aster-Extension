"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Lock, Clock, AlertCircle } from "lucide-react"
import { Switch } from "@/components/ui/switch"

interface ExtensionCaptchaCardProps {
  name: string
  description: string
  logo: React.ReactNode
  isPopular?: boolean
  isActive?: boolean
  color: string
  animationDelay?: number
  status?: 'available' | 'coming-soon' | 'suspended'
  onToggle?: (name: string, isEnabled: boolean) => void
}

export function ExtensionCaptchaCard({
  name,
  description,
  logo,
  isPopular = false,
  isActive = false,
  color,
  animationDelay = 0,
  status = 'available',
  onToggle,
}: ExtensionCaptchaCardProps) {
  const [enabled, setEnabled] = useState(isActive)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), animationDelay)
    return () => clearTimeout(timer)
  }, [animationDelay])

  const handleToggle = (checked: boolean) => {
    setEnabled(checked)
    onToggle?.(name, checked)
  }

  const getStatusBadge = () => {
    switch (status) {
      case 'coming-soon':
        return (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full dark:bg-amber-900/50 dark:text-amber-300 bg-amber-100 text-[9px] font-medium text-amber-700">
            <Clock className="w-3 h-3" />
            Coming Soon
          </div>
        )
      case 'suspended':
        return (
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full dark:bg-red-900/50 dark:text-red-300 bg-red-100 text-[9px] font-medium text-red-700">
            <AlertCircle className="w-3 h-3" />
            Suspended
          </div>
        )
      default:
        return null
    }
  }

  const isDisabled = status !== 'available'

  return (
    <div
      className={`relative p-3 rounded-xl border transition-all duration-300 ${
        isDisabled 
          ? "dark:bg-gray-800/30 dark:border-gray-700/50 bg-muted/30 border-muted/50 opacity-60" 
          : enabled 
            ? "dark:bg-primary/10 dark:border-primary/40 bg-primary/5 border-primary/30" 
            : "dark:bg-gray-800/30 dark:border-gray-600/20 dark:hover:border-primary/30 bg-secondary/30 border-border hover:border-primary/20"
      } ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
    >
      {/* Status Badges */}
      <div className="absolute -top-2 right-3 flex gap-1">
        {isPopular && (
          <div className="px-2 py-0.5 rounded-full dark:bg-primary/90 dark:text-primary-foreground bg-primary text-[9px] font-medium text-primary-foreground">
            Popular
          </div>
        )}
        {getStatusBadge()}
      </div>

      <div className="flex items-center gap-3">
        {/* Logo */}
        <div
          className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
          style={{ backgroundColor: `${color}15` }}
        >
          {logo}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <h3 className="text-xs font-semibold text-foreground truncate">{name}</h3>
          <p className="text-[10px] text-muted-foreground truncate">{description}</p>
        </div>

        {/* Toggle */}
        {isDisabled ? (
          <div className="w-10 h-5 rounded-full dark:bg-gray-700 dark:border-gray-600/30 bg-muted border-2 border-muted-foreground/30 flex items-center justify-center">
            <Lock className="w-3 h-3 dark:text-gray-500 text-muted-foreground/50" />
            
          </div>
        ) : (
          <Switch checked={enabled} onCheckedChange={handleToggle} className="data-[state=checked]:bg-primary shrink-0" />
        )}
      </div>

    </div>
  )
}
