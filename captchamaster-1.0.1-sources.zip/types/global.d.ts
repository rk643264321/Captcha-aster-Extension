declare global {
  namespace chrome {
    namespace runtime {
      function sendMessage(message: any): void;
      function sendMessage(message: any, callback?: (response?: any) => void): void;
      const lastError: { message?: string } | null;
      const onMessage: {
        addListener(callback: (message: any, sender: any, sendResponse: (response?: any) => void) => boolean | void): void;
      };
    }
    
    namespace storage {
      namespace local {
        function get(keys?: string | string[] | Record<string, any> | null): Promise<Record<string, any>>;
        function get(keys: string | string[] | Record<string, any> | null, callback: (items: Record<string, any>) => void): void;
        function set(items: Record<string, any>): Promise<void>;
        function set(items: Record<string, any>, callback?: () => void): void;
        function remove(keys: string | string[]): Promise<void>;
        function remove(keys: string | string[], callback?: () => void): void;
        function clear(): Promise<void>;
        function clear(callback?: () => void): void;
      }
    }
  }
}

export {};
