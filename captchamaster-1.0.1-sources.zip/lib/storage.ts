 

// Chrome storage utility
const getStorageData = <T>(key: string, defaultValue: T): Promise<T> => {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get([key], (result: Record<string, any>) => {
        resolve(result[key] !== undefined ? result[key] : defaultValue)
      })
    } else {
      resolve(defaultValue)
    }
  })
}

const setStorageData = <T>(key: string, value: T): Promise<void> => {
  return new Promise((resolve) => {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ [key]: value }, () => {
        resolve()
      })
    } else {
      resolve()
    }
  })
}

export { getStorageData, setStorageData }
