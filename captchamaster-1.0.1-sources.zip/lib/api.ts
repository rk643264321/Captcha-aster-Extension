import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse } from "axios";

interface ApiHeaders {
    contentType?: 'json' | 'image' | 'text' | 'video';
    'X-CSRF-Token'?: string;
    Authorization?: string;
    [key: string]: any;
}

interface ApiCallProps {
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
    url: string;
    baseURL?: string;
    body?: any;
    apiVersion?: string;
    headers?: ApiHeaders;
    params?: Record<string, any>;
}

interface ApiResponse<T = any> {
    status: number;
    response: T;
}



/**
 * Make an API call with authentication and error handling
 * @param props - API call configuration
 * @returns Promise with API response containing status and data
 */


export const API_BASE_URL =  'https://api.captchamaster.org';



const API_CALL = async <T = any>(props: ApiCallProps): Promise<ApiResponse<T>> => {
    let baseUrl = props.baseURL;

    if (typeof window !== 'undefined') {
        // Only access window.location when in browser environment
        baseUrl = baseUrl || API_BASE_URL
    } else {
        // Fallback for server-side rendering
        baseUrl = baseUrl || '/api';
    }

    const api: AxiosInstance = axios.create({
        baseURL: baseUrl,
        timeout: 10000, // Add timeout for extension environment
    });

    // Define default headers for different content types
    const defaultHeaders = {
        'Content-Type': 'application/json'
    };

    // Add fingerprint authentication headers if enabled
    let authHeaders: Record<string, string> = {};

    const config: AxiosRequestConfig = {
        ...props,
        data: props.body || undefined,
        headers: {
            ...defaultHeaders,
            ...authHeaders,
            ...props?.headers,
        },
    };

    try {
        // If contentType is 'image', use FormData for image upload
        if (props.headers?.contentType === 'image') {
            const formData = new FormData();
            formData.append('image', props.body);
            config.data = formData;
            // Remove Content-Type header to let browser set it with boundary
            config.headers?.['Content-Type'] && delete config.headers['Content-Type'];
        }

        const response: AxiosResponse<T> = await api(config);

        return {
            status: response.status,
            response: response.data,
        };
    } catch (error) {


        if (axios.isAxiosError(error)) {
            if (error.response) {
                return {
                    status: error.response.status,
                    response: error.response.data as T,
                };
            } else if (error.request) {

                // More specific error handling for extension environment
                const errorMessage = error.code === 'ECONNREFUSED' || error.code === 'ERR_NETWORK'
                    ? 'Network error - please check your internet connection'
                    : 'Network error occurred';
                return {
                    status: 500,
                    response: { message: { error: errorMessage }, status: 'internet_error' } as T,
                };
            } else {
                return {
                    status: 500,
                    response: { message: { error: 'An error occurred: ' + error.message } } as T,
                };
            }
        } else {
            return {
                status: 500,
                response: { message: { error: 'An unexpected error occurred' } } as T,
            };
        }
    }
};

export default API_CALL;



