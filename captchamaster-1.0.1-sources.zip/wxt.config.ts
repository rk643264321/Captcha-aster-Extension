import { defineConfig } from 'wxt';

export default defineConfig({
  modules: ['@wxt-dev/module-react', '@wxt-dev/auto-icons'],

  /* =========================
     Manifest Configuration
  ========================== */
  manifest: {
    name: 'CaptchaⱮaster',
    description: 'Detects and assists with hCaptcha, Cloudflare Turnstile & reCAPTCHA challenges',
    version: '1.0.1',

    // Required permissions
    permissions: [
      'tabs',
      'scripting',
      'activeTab',
      'storage', // ✅ added
    ],
 

    // Allow captcha sites
    host_permissions: [
      '*://*/*',
    ],

     icons: {
      16: 'icons/16.png',
      32: 'icons/32.png',
      48: 'icons/48.png',
      128: 'icons/128.png',
    },
    action: {
      default_title: 'CaptchaⱮaster',
    },
  },

  /* =========================
     Vite / Tailwind
  ========================== */
  vite: () => ({
    css: {
      postcss: {
        plugins: [
          require('@tailwindcss/postcss'),
        ],
      },
    },
  }),
});
