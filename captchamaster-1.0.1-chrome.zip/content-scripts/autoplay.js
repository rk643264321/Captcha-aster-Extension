var autoplay=(function(){"use strict";function y(e){return e}const d=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,b={matches:["*://*.kolotibablo.com/*"],main(){const e="config_services";let t=null,o;function n(){if(document.getElementById("cm-autoplay-toast-style"))return;const r=document.createElement("style");r.id="cm-autoplay-toast-style",r.textContent=`
                @keyframes cm-toast-slide-in {
                    from { opacity: 0; transform: translateX(120%) scale(0.9); }
                    to { opacity: 1; transform: translateX(0) scale(1); }
                }
                .cm-toast-binance {
                    position: fixed !important; 
                    top: 80px !important; 
                    right: 24px !important; 
                    bottom: auto !important; 
                    left: auto !important;
                    z-index: 2147483647 !important;
                    min-width: 300px; padding: 16px 20px; border-radius: 12px;
                    background: rgba(30, 35, 41, 0.95); backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.08); color: #eaecef;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.4); font-family: sans-serif;
                    display: flex; align-items: center; gap: 12px; overflow: hidden;
                    animation: cm-toast-slide-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                .cm-toast-icon { width: 22px; height: 22px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: 6px; background: rgba(255,255,255,0.05); color: #f0b90b; }
                .cm-toast-content { flex: 1; }
                .cm-toast-title { font-weight: 600; font-size: 14px; color: #fff; margin-bottom: 2px; }
                .cm-toast-msg { font-size: 12px; color: #b7bdc6; }
                .cm-toast-progress-track { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: rgba(255,255,255,0.05); }
                .cm-toast-progress { height: 100%; width: 100%; transform-origin: left; transform: scaleX(1); background: #f0b90b; }
            `,document.head.appendChild(r)}function i(r,s){n(),t&&t.remove(),t=document.createElement("div"),t.className="cm-toast-binance",t.innerHTML=`
                <div class="cm-toast-icon">▶️</div>
                <div class="cm-toast-content">
                    <div class="cm-toast-title">${r}</div>
                    <div class="cm-toast-msg">${s}</div>
                </div>
                <div class="cm-toast-progress-track">
                    <div class="cm-toast-progress"></div>
                </div>
            `,document.body.appendChild(t);const p=t.querySelector(".cm-toast-progress");setTimeout(()=>{p.style.transition="transform 3000ms linear",p.style.transform="scaleX(0)"},10),clearTimeout(o),o=window.setTimeout(()=>{t?.remove(),t=null},3e3)}const g=()=>new Promise(r=>{d.storage.local.get(e).then(s=>{r(!!s?.[e]?.["Auto Play"]?.enable)})});async function h(){if(!await g())return;const s=document.querySelector("div.play");s&&(console.log("▶️ Play/Resume button detected → Clicking..."),i("Auto Resuming","Play/Resume button clicked automatically"),setTimeout(()=>{s.click()},5e3))}h(),new MutationObserver(()=>{h()}).observe(document.body,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class"]}),chrome.storage.onChanged.addListener(r=>{r[e]&&h()}),console.log("👀 MutationObserver active: Watching for play button...")}};function a(e,...t){}const f={debug:(...e)=>a(console.debug,...e),log:(...e)=>a(console.log,...e),warn:(...e)=>a(console.warn,...e),error:(...e)=>a(console.error,...e)};class u extends Event{constructor(t,o){super(u.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=o}static EVENT_NAME=m("wxt:locationchange")}function m(e){return`${d?.runtime?.id}:autoplay:${e}`}function v(e){let t,o;return{run(){t==null&&(o=new URL(location.href),t=e.setInterval(()=>{let n=new URL(location.href);n.href!==o.href&&(window.dispatchEvent(new u(n,o)),o=n)},1e3))}}}class c{constructor(t,o){this.contentScriptName=t,this.options=o,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=m("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=v(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return d.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,o){const n=setInterval(()=>{this.isValid&&t()},o);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(t,o){const n=setTimeout(()=>{this.isValid&&t()},o);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(t){const o=requestAnimationFrame((...n)=>{this.isValid&&t(...n)});return this.onInvalidated(()=>cancelAnimationFrame(o)),o}requestIdleCallback(t,o){const n=requestIdleCallback((...i)=>{this.signal.aborted||t(...i)},o);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(t,o,n,i){o==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(o.startsWith("wxt:")?m(o):o,n,{...i,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),f.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:c.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){const o=t.data?.type===c.SCRIPT_STARTED_MESSAGE_TYPE,n=t.data?.contentScriptName===this.contentScriptName,i=!this.receivedMessageIds.has(t.data?.messageId);return o&&n&&i}listenForNewerScripts(t){let o=!0;const n=i=>{if(this.verifyScriptStartedEvent(i)){this.receivedMessageIds.add(i.data.messageId);const g=o;if(o=!1,g&&t?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",n),this.onInvalidated(()=>removeEventListener("message",n))}}function S(){}function l(e,...t){}const w={debug:(...e)=>l(console.debug,...e),log:(...e)=>l(console.log,...e),warn:(...e)=>l(console.warn,...e),error:(...e)=>l(console.error,...e)};return(async()=>{try{const{main:e,...t}=b,o=new c("autoplay",t);return await e(o)}catch(e){throw w.error('The content script "autoplay" crashed on startup!',e),e}})()})();
autoplay;