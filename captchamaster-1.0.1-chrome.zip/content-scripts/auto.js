var auto=(function(){"use strict";function S(e){return e}const f={matches:["*://*.kolotibablo.com/*"],main(){const e="config_services";let t=null,n;function o(){if(document.getElementById("cm-toast-style-binance"))return;const r=document.createElement("style");r.id="cm-toast-style-binance",r.textContent=`
                @keyframes cm-toast-slide-in {
                    from { opacity: 0; transform: translateX(120%) scale(0.9); }
                    to { opacity: 1; transform: translateX(0) scale(1); }
                }
                .cm-toast-binance {
                    position: fixed !important; 
                    top: 24px !important; 
                    right: 24px !important; 
                    bottom: auto !important; 
                    left: auto !important;
                    z-index: 2147483647 !important;
                    min-width: 320px; padding: 16px 20px; border-radius: 12px;
                    background: rgba(30, 35, 41, 0.95); backdrop-filter: blur(20px);
                    border: 1px solid rgba(255, 255, 255, 0.08); color: #eaecef;
                    box-shadow: 0 8px 32px rgba(0,0,0,0.4); font-family: sans-serif;
                    display: flex; align-items: center; gap: 12px; overflow: hidden;
                    animation: cm-toast-slide-in 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
                }
                .cm-toast-icon { width: 22px; height: 22px; flex-shrink: 0; display: flex; align-items: center; justify-content: center; border-radius: 6px; background: rgba(255,255,255,0.05); }
                .cm-toast-content { flex: 1; }
                .cm-toast-title { font-weight: 600; font-size: 14px; color: #fff; margin-bottom: 2px; }
                .cm-toast-msg { font-size: 12px; color: #b7bdc6; }
                .cm-toast-progress-track { position: absolute; bottom: 0; left: 0; right: 0; height: 3px; background: rgba(255,255,255,0.05); }
                .cm-toast-progress { height: 100%; width: 100%; transform-origin: left; transform: scaleX(1); }
                .cm-toast-binance.success .cm-toast-icon { color: #0ecb81; }
                .cm-toast-binance.success .cm-toast-progress { background: #0ecb81; }
                .cm-toast-binance.warn .cm-toast-icon { color: #f0b90b; }
                .cm-toast-binance.warn .cm-toast-progress { background: #f0b90b; }
            `,document.head.appendChild(r)}function s(r,i,b="success"){o(),t&&t.remove(),t=document.createElement("div"),t.className=`cm-toast-binance ${b}`,t.innerHTML=`
                <div class="cm-toast-icon">${b==="success"?"⚡":"⚠️"}</div>
                <div class="cm-toast-content">
                    <div class="cm-toast-title">${r}</div>
                    <div class="cm-toast-msg">${i}</div>
                </div>
                <div class="cm-toast-progress-track">
                    <div class="cm-toast-progress"></div>
                </div>
            `,document.body.appendChild(t);const p=t.querySelector(".cm-toast-progress");setTimeout(()=>{p.style.transition="transform 5000ms linear",p.style.transform="scaleX(0)"},10),clearTimeout(n),n=window.setTimeout(()=>{t?.remove(),t=null},5e3)}const u=()=>new Promise(r=>{chrome.storage.local.get(e,i=>{r(!!i?.[e]?.["Auto Worker"]?.enable)})}),g=async()=>{if(await u()){const i=document.querySelector(".btn.btn-primary.margin5px");i instanceof HTMLElement&&(console.log("Auto Worker: Detected start button, clicking..."),s("Auto Worker: Detected start button, clicking...","info"),setTimeout(()=>{i.click()},1e3*10))}};chrome.storage.onChanged.addListener(r=>{r[e]&&g()}),new MutationObserver(g).observe(document.body,{childList:!0,subtree:!0}),g()}},h=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function a(e,...t){}const v={debug:(...e)=>a(console.debug,...e),log:(...e)=>a(console.log,...e),warn:(...e)=>a(console.warn,...e),error:(...e)=>a(console.error,...e)};class d extends Event{constructor(t,n){super(d.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}static EVENT_NAME=m("wxt:locationchange")}function m(e){return`${h?.runtime?.id}:auto:${e}`}function w(e){let t,n;return{run(){t==null&&(n=new URL(location.href),t=e.setInterval(()=>{let o=new URL(location.href);o.href!==n.href&&(window.dispatchEvent(new d(o,n)),n=o)},1e3))}}}class c{constructor(t,n){this.contentScriptName=t,this.options=n,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=m("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=w(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){return h.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,n){const o=setInterval(()=>{this.isValid&&t()},n);return this.onInvalidated(()=>clearInterval(o)),o}setTimeout(t,n){const o=setTimeout(()=>{this.isValid&&t()},n);return this.onInvalidated(()=>clearTimeout(o)),o}requestAnimationFrame(t){const n=requestAnimationFrame((...o)=>{this.isValid&&t(...o)});return this.onInvalidated(()=>cancelAnimationFrame(n)),n}requestIdleCallback(t,n){const o=requestIdleCallback((...s)=>{this.signal.aborted||t(...s)},n);return this.onInvalidated(()=>cancelIdleCallback(o)),o}addEventListener(t,n,o,s){n==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),t.addEventListener?.(n.startsWith("wxt:")?m(n):n,o,{...s,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),v.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:c.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(t){const n=t.data?.type===c.SCRIPT_STARTED_MESSAGE_TYPE,o=t.data?.contentScriptName===this.contentScriptName,s=!this.receivedMessageIds.has(t.data?.messageId);return n&&o&&s}listenForNewerScripts(t){let n=!0;const o=s=>{if(this.verifyScriptStartedEvent(s)){this.receivedMessageIds.add(s.data.messageId);const u=n;if(n=!1,u&&t?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",o),this.onInvalidated(()=>removeEventListener("message",o))}}function T(){}function l(e,...t){}const E={debug:(...e)=>l(console.debug,...e),log:(...e)=>l(console.log,...e),warn:(...e)=>l(console.warn,...e),error:(...e)=>l(console.error,...e)};return(async()=>{try{const{main:e,...t}=f,n=new c("auto",t);return await e(n)}catch(e){throw E.error('The content script "auto" crashed on startup!',e),e}})()})();
auto;